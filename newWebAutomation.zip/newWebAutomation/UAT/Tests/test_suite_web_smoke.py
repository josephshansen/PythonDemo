import unittest
from UAT.Tests.homepage_tests import homepageTests
from UAT.Tests.locations_tests import locationsTests
from UAT.Tests.void_story_tests import voidStoryTests
from UAT.Tests.events_tests import eventsPageTests
from UAT.Tests.giftcard_tests import giftcardPageTests
from UAT.Tests.avengers_links_tests import avengersLinksTests
from UAT.Tests.ghostbusters_links_tests import ghostbustersLinksTests
from UAT.Tests.jumanji_links_tests import jumanjiLinksTests
from UAT.Tests.nicodemus_links_tests import nicodemusLinksTests
from UAT.Tests.ralph_links_tests import ralphLinksTests
from UAT.Tests.star_wars_links_tests import starWarsLinksTests
from UAT.Tests.join_team_tests import joinTeamTests

# This is an example of a test suite, where multiple test files can be run at once.
# To run this file, open vscodes terminal and type py.test .\Tests\test_suite_web_smoke.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

tsHome = unittest.TestLoader().loadTestsFromTestCase(homepageTests)
tsLocations = unittest.TestLoader().loadTestsFromTestCase(locationsTests)
tsStory = unittest.TestLoader().loadTestsFromTestCase(voidStoryTests)
tsEvents = unittest.TestLoader().loadTestsFromTestCase(eventsPageTests)
tsGiftcard = unittest.TestLoader().loadTestsFromTestCase(giftcardPageTests)
tsAvengers = unittest.TestLoader().loadTestsFromTestCase(avengersLinksTests)
tsGhostbusters = unittest.TestLoader().loadTestsFromTestCase(ghostbustersLinksTests)
tsJumanji = unittest.TestLoader().loadTestsFromTestCase(jumanjiLinksTests)
tsNicodemus = unittest.TestLoader().loadTestsFromTestCase(nicodemusLinksTests)
tsRalph = unittest.TestLoader().loadTestsFromTestCase(ralphLinksTests)
tsStarWars = unittest.TestLoader().loadTestsFromTestCase(starWarsLinksTests)
tsJoinTeam = unittest.TestLoader().loadTestsFromTestCase(joinTeamTests)

websiteSmoko = unittest.TestSuite([tsHome, tsLocations, tsStory, tsEvents, tsGiftcard, tsAvengers, tsGhostbusters, tsJumanji, tsNicodemus, tsRalph, tsStarWars, tsJoinTeam]) 

# unittest.TextTestRunner(verbosity=2).run(websiteSmoko)
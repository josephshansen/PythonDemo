from selenium import webdriver
from UAT.Pages.join_team import JoinTeam
from UAT.base.webdriver_factory import webDriverFactory
import unittest
import pytest


# This is the actualy join team page test. It calls from join_team.py
# To run this test alone, just type in the commandline from within vscode py.test .\Tests\join_team_tests.py --browser chrome
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class joinTeamTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        # pylint: disable=no-member
        self.jt = JoinTeam(self.driver)

    @pytest.mark.run()
    def test_join_team_page(self):
        # pylint: disable=no-member
        self.jt.checkJoinTeamLinks()
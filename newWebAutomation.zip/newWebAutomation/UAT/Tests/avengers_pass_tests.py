from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from UAT.base.webdriver_factory import webDriverFactory
from UAT.Pages.avengers_two_travelers import AvengersBookings
from UAT.utilities.read_data import getCSVData
from ddt import ddt, data, unpack
from datetime import datetime
import os
import unittest
import pytest
import requests

# This is the actual Avengers pass test. They are called from avengers_two_travelers.py.
# To run these tests alone, open vscodes terminal and type py.test .\Tests\avengers_pass_tests.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
@ddt
class avengersBookingsTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        # pylint: disable=no-member
        self.ab = AvengersBookings(self.driver)

    @pytest.mark.run()
    @data(*getCSVData(os.path.normpath(os.path.realpath("avengers.csv"))))
    @unpack
    def test_avengers_bookings(self, name, email):
        # pylint: disable=no-member
        self.ab.avengersTwoBookings(name, email)
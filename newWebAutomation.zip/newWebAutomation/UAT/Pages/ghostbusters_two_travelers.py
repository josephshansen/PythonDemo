from selenium import webdriver
from selenium.webdriver.common.by import By
from UAT.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
import time
import UAT.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the ghostbusters_pass_tests.py are defined. 
"""

class GhostbustersBookings(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
    _select_ghostbusters_tile = 'buttonBookNow-dimensionCard-dimension-15'
    _home_icon = 'globalNav-link-home'
    _play_video = 'button-dimensionPage-playTrailer'
    _choose_location = 'button-dimensionPage-chooseLocation'
    _location_list = 'modal-content' #class
    _more_times = 'button-seeMoreTimes-ghostbusters-vr'
    _eight_pm = 'time-2000'
    _lindon = 'link-vecId-2'
    _choose_time = 'button-timeListItem-1'
    _change_location = 'button-filterLocation'
    _verify_change_location = 'modal-chooseLocationToBook'
    _close_change_location = 'close-nav'
    _contact_link_star_wars = 'link-events-contactUs'
    _verify_contact_page = 'fullName'
    _book_now = 'dimensionView-buttonBookNow'
    _book_two_travelers = 'travelerOption-1'
    _checkout_two_travelers = '//span[text()="2 travel passes for"]'
    _checkout_ghostbusters = '//span[text()="Ghostbusters"]'
    _checkout_details = '//p[text()="General Admission (Ages 10+) ($29.95 × 2)"]'
    _checkout_total = '//p[text()="$59.90"]'
    _checkout_tax = '//p[text()="$3.89"]'
    _grand_total = '//p[text()="$63.79"]'
    _full_name = 'fullName'
    _email = 'email'
    _phone = 'react-phone-number-input__phone' #class
    _card_holder = 'cardholderName'
    _card_number = 'CardField-input-wrapper' #class
    _legal_checkbox = 'legalCheckbox'
    _submit_payment = 'button-formSubmit-'
    _verify_purchase_successful = 'button-travelPass-claimPass-1'

    def enterName(self, name):
        return self.sendKeys(name, self._full_name)

    def enterEmail(self, email):
        return self.sendKeys(email, self._email)

    def enterPhone(self, phone):
        return self.sendKeys(phone, self._phone, locatorType='class')

    def enterCardHolder(self, cardHolder):
        return self.sendKeys(cardHolder, self._card_holder)

    def enterCardNumber(self, cardNumber):
        return self.sendKeys(cardNumber, self._card_number, locatorType='class')

    def legalCheckbox(self):
        return self.elementClick(self._legal_checkbox)

    def submitPayment(self):
        return self.elementClick(self._submit_payment)

    def verifyPurchaseSuccess(self):
        return self.isElementPresent(self._verify_purchase_successful)

    def goToGhostbustersPage(self):
        return self.elementClick(self._select_ghostbusters_tile)

    def goHome(self):
        return self.elementClick(self._home_icon)

    def bookNow(self):
        return self.elementClick(self._book_now)

    def bookTwoTravelers(self):
        return self.elementClick(self._book_two_travelers)

    def verifyTwoTravelers(self):
        return self.isElementPresent(self._checkout_two_travelers, locatorType='xpath')

    def verifyGhostbustersCheckout(self):
        return self.isElementPresent(self._checkout_ghostbusters, locatorType='xpath')

    def verifyCheckoutDetails(self):
        return self.isElementPresent(self._checkout_details, locatorType='xpath')

    def verifyCheckoutTotal(self):
        return self.isElementPresent(self._checkout_total, locatorType='xpath')

    def verifyGrandTotal(self):
        return self.isElementPresent(self._grand_total, locatorType='xpath')

    def playGhostbustersVideo(self):
        return self.elementClick(self._play_video)

    def chooseLocationLink(self):
        return self.elementClick(self._choose_location)

    def windowAfter(self):
        window_after = self.driver.window_handles[1]
        return self.driver.switch_to.window(window_after)

    def chooseLindon(self):
        return self.elementClick(self._lindon)

    def selectTime(self):
        return self.elementClick(self._choose_time)

    def goBack(self):
        return self.driver.back()

    def scrollToTimes(self):
        return self.driver.execute_script("window.scrollTo(500, document.body.scrollHeight);")

    def verifyTimeSelected(self):
        return self.driver.find_element_by_id(self._choose_time).is_selected()

    def verifyLocationLink(self):
        return self.isElementPresent(self._verify_change_location)

    def verifyGhostbustersPage(self):
        return self.isElementPresent(self._play_video)

    def clickGhostbustersMoreTimes(self):
        try:
            additionalTimes = self.driver.find_element_by_id('button-seeMoreTimes-ghostbusters-vr').is_displayed
            if additionalTimes:
                self.elementClick(self._more_times)
                self.log.info('See More Times is Displayed')
                self.elementClick(self._eight_pm)
            else:
                self.log.info('See More Times is Not Displayed')
        except:
            NoSuchElementException
            self.log.info('See More Times is Not Displayed')

######TESTS######        
    def ghostbustersTwoBookings(self, name, email, phone, cardHolder, cardNumber):
        self.goToGhostbustersPage()
        time.sleep(2)
        self.verifyGhostbustersPage()
        self.chooseLocationLink()
        time.sleep(2)
        self.chooseLindon()
        time.sleep(4)
        self.scrollToTimes()
        self.clickGhostbustersMoreTimes()
        time.sleep(2)
        self.selectTime()
        self.verifyTimeSelected()
        self.bookNow()
        time.sleep(2)
        self.bookTwoTravelers()
        time.sleep(4)
        self.verifyTwoTravelers()
        self.verifyGhostbustersCheckout()
        self.verifyCheckoutDetails()
        self.verifyCheckoutTotal()
        self.verifyGrandTotal()
        self.enterName(name)
        self.enterEmail(email)
        self.enterPhone(phone)
        self.enterCardHolder(cardHolder)
        self.enterCardNumber(cardNumber)
        self.legalCheckbox()
        self.submitPayment()
        time.sleep(6)
        self.verifyPurchaseSuccess()
        self.goHome()
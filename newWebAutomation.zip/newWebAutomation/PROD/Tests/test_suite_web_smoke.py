import unittest
from PROD.Tests.homepage_tests import homepageTests
from PROD.Tests.locations_tests import locationsTests
from PROD.Tests.void_story_tests import voidStoryTests
from PROD.Tests.events_tests import eventsPageTests
from PROD.Tests.giftcard_tests import giftcardPageTests
from PROD.Tests.avengers_links_tests import avengersLinksTests
from PROD.Tests.ghostbusters_links_tests import ghostbustersLinksTests
from PROD.Tests.jumanji_links_tests import jumanjiLinksTests
from PROD.Tests.nicodemus_links_tests import nicodemusLinksTests
from PROD.Tests.ralph_links_tests import ralphLinksTests
from PROD.Tests.star_wars_links_tests import starWarsLinksTests
from PROD.Tests.join_team_tests import joinTeamTests

# This is an example of a test suite, where multiple test files can be run at once.
# To run this file, open vscodes terminal and type py.test .\Tests\test_suite_web_smoke.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

tsHome = unittest.TestLoader().loadTestsFromTestCase(homepageTests)
tsLocations = unittest.TestLoader().loadTestsFromTestCase(locationsTests)
tsStory = unittest.TestLoader().loadTestsFromTestCase(voidStoryTests)
tsEvents = unittest.TestLoader().loadTestsFromTestCase(eventsPageTests)
tsGiftcard = unittest.TestLoader().loadTestsFromTestCase(giftcardPageTests)
tsAvengers = unittest.TestLoader().loadTestsFromTestCase(avengersLinksTests)
tsGhostbusters = unittest.TestLoader().loadTestsFromTestCase(ghostbustersLinksTests)
tsJumanji = unittest.TestLoader().loadTestsFromTestCase(jumanjiLinksTests)
tsNicodemus = unittest.TestLoader().loadTestsFromTestCase(nicodemusLinksTests)
tsRalph = unittest.TestLoader().loadTestsFromTestCase(ralphLinksTests)
tsStarWars = unittest.TestLoader().loadTestsFromTestCase(starWarsLinksTests)
tsJoinTeam = unittest.TestLoader().loadTestsFromTestCase(joinTeamTests)

websiteSmoko = unittest.TestSuite([tsHome, tsLocations, tsStory, tsEvents, tsGiftcard, tsAvengers, tsGhostbusters, tsJumanji, tsNicodemus, tsRalph, tsStarWars, tsJoinTeam]) 

# unittest.TextTestRunner(verbosity=2).run(websiteSmoko)
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from PROD.base.webdriver_factory import webDriverFactory
from PROD.Pages.homepage import HomePage
from PROD.utilities.read_data import getCSVData
from ddt import ddt, data, unpack
import time
import unittest
import pytest
import os


# These are the actual homepage tests. They are called from homepage.py.
# To run these tests alone, open vscodes terminal and type py.test .\Tests\homepage_tests.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.


@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
@ddt
class homepageTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        # pylint: disable=no-member
        self.hp = HomePage(self.driver)

    @pytest.mark.run(order=1)
    def test_homepage_loads(self):
        self.hp.homePageLoads()
        result = self.hp.verifyJumanjiSynopsis()
        assert result == True

    @pytest.mark.run(order=2)
    def test_jumanji_tile(self):
        self.hp.jumanjiTileLink()
        result = self.hp.verifyHomePage()
        assert result == True

    @pytest.mark.run(order=3)
    # @data(*getCSVData(os.path.normpath(os.path.realpath("homepage.csv"))))
    # @unpack
    def test_notification_send(self):
        # pylint: disable=no-member
        self.hp.verifyNotificationSent()
        # time.sleep(2)
        # result = self.hp.verifyNotificationSuccess()
        # assert result == True
        self.driver.refresh()

    @pytest.mark.run(order=4)
    def test_events_Card(self):
        # pylint: disable=no-member
        self.hp.verifyEventsLink()
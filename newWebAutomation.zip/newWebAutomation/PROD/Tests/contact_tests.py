from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from PROD.base.webdriver_factory import webDriverFactory
from PROD.Pages.contact import ContactPage
import unittest
import pytest
import requests

# This is the actual contact page tests. They are called from contact.py.
# To run these tests alone, open vscodes terminal and type py.test .\Tests\contact_tests.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class contactPageTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        # pylint: disable=no-member
        self.cp = ContactPage(self.driver)

    @pytest.mark.run()
    def test_contact_page(self):
        # pylint: disable=no-member
        self.cp.generalContactCheck()
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from PROD.base.webdriver_factory import webDriverFactory
from PROD.Pages.star_wars_experience import StarWarsExperience
import unittest
import pytest
import requests

# This is the actual star wars links test. They are called from star_wars_experience.py.
# To run these tests alone, open vscodes terminal and type py.test .\Tests\star_wars_links_tests.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class starWarsLinksTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        # pylint: disable=no-member
        self.sw = StarWarsExperience(self.driver)

    @pytest.mark.run()
    def test_star_wars_links(self):
        # pylint: disable=no-member
        self.sw.starWarsExperience()
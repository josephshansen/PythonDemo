from selenium import webdriver
from PROD.Pages.locations import LocationsPage
from PROD.base.webdriver_factory import webDriverFactory
import unittest
import pytest


# This is the actual locations test. They are called from locations.py.
# To run these tests alone, open vscodes terminal and type py.test .\Tests\locations_tests.py --browser chrome 
# Or if you want to use a different browser, change it from chrome to another browser name (be sure that the driver is 
# set in the path under webdriver_factory.py or in your system path)
# Open automation.log to see the logged results of the test.

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class locationsTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        # pylint: disable=no-member
        self.lp = LocationsPage(self.driver)

    @pytest.mark.run()
    def test_locations_page(self):
        # pylint: disable=no-member
        self.lp.locationsTest()
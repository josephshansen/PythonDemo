import inspect
import coloredlogs, logging
coloredlogs.install()

"""
This is where the logging method is created which the custom_webdriver utilizes.
"""

def customLogger(logLevel=logging.DEBUG):
    # Gets the name of the class / method from where this method is called
    loggerName = inspect.stack()[1][3]
    logger = coloredlogs.logging.getLogger(loggerName)
    # By default, log all messages
    logger.setLevel(coloredlogs.logging.DEBUG)

    fileHandler = logging.FileHandler("automation_PROD.log", mode='a')
    fileHandler.setLevel(logLevel)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S %p')
    fileHandler.setFormatter(formatter)
    logger.addHandler(fileHandler)

    return logger

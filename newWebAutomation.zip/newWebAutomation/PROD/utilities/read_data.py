import csv

"""
In place of json files, I am using csv files. This function allows the driver to read the csv file
and input the data in the tests. 
All CSV files are under the folder inputData
"""

def getCSVData(fileName):
    rows = []
    dataFile = open(fileName, "r")
    reader = csv.reader(dataFile)
    next(reader)
    for row in reader:
        rows.append(row)
        return rows
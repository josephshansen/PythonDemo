from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
import requests
coloredlogs.install()

"""
This is where all elements for the events_tests.py are defined. 
"""

class EventsPage(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

#Locators
    _events_link = 'globalNav-link-events'
    _events_synopsis = '//p[text()="Explore The sd as a group event. Up to four travelers can explore together at a time. For 13 people or more, please tell us more about your event below. One of our guides will contact you with more details."]'
    _submit_form = 'button-formSubmit-eventsForm'
    _name_error = '//span[text()="Please enter your first and last name."]'
    _email_error = '//span[text()="Invalid email address. Check for typos and try again."]'
    _group_error = '//span[text()="Please select a group size."]'
    _description_error = '//span[text()="Please give us some details about your event."]'
    _faq_button = 'button-viewFaq'
    _faq_discount = '//span[text()="Does The VOID offer group discounts or promotions?"]'
    _faq_discount_inquiry = 'inquiry'
    _faq_packages = '//span[text()="Does The VOID have packages for large group bookings (e.g. corporate events, birthdays, bachelor/ette parties, special events)?"]'
    _faq_page = '//span[text()="Frequently Asked Questions"]'
    _home_icon = 'globalNav-link-home'
    _events_nav_link = 'globalNav-link-events'
    _location_list = 'location'
    _anaheim = 'formSelect-option-1'
    _atlanta = 'formSelect-option-2'
    _dubai = 'formSelect-option-3'
    _edmonton = 'formSelect-option-4'
    _genting = 'formSelect-option-5'
    _glendale = 'formSelect-option-6'
    _las_vegas = 'formSelect-option-7'
    _minneapolis = 'formSelect-option-8'
    _mississauga = 'formSelect-option-9'
    _new_york = 'formSelect-option-10'
    _orlando = 'formSelect-option-11'
    _plano = 'formSelect-option-12'
    _san_francisco = 'formSelect-option-13'
    _santa_anita = 'formSelect-option-14'
    _santa_monica = 'formSelect-option-15'
    _toronto = 'formSelect-option-16'
    _washington_dc = 'formSelect-option-17'
    _group_size = 'groupSize'
    _thirteen = 'formSelect-option-1'
    _twenty_one = 'formSelect-option-2'
    _fifty_one = 'formSelect-option-3'
    _one_hundred = 'formSelect-option-4'

    def verifyGroupSize(self):
        self.elementClick(self._group_size)
        self.isElementPresent(self._thirteen)
        self.isElementPresent(self._twenty_one)
        self.isElementPresent(self._fifty_one)
        self.isElementPresent(self._one_hundred)
        self.elementClick(self._group_size)

    def verifyEventLocationList(self):
        self.elementClick(self._location_list)
        self.isElementPresent(self._anaheim)
        self.isElementPresent(self._atlanta)
        self.isElementPresent(self._dubai)
        self.isElementPresent(self._edmonton)
        self.isElementPresent(self._genting)
        self.isElementPresent(self._glendale)
        self.isElementPresent(self._las_vegas)
        self.isElementPresent(self._minneapolis)
        self.isElementPresent(self._mississauga)
        self.isElementPresent(self._new_york)
        self.isElementPresent(self._orlando)
        self.isElementPresent(self._plano)
        self.isElementPresent(self._san_francisco)
        self.isElementPresent(self._santa_anita)
        self.isElementPresent(self._santa_monica)
        self.isElementPresent(self._toronto)
        self.isElementPresent(self._washington_dc)
        self.elementClick(self._location_list)

    def goToEventsPage(self):
        return self.elementClick(self._events_link)

    def verifySynopsis(self):
        return self.elementClick(self._events_synopsis)

    def eventsNavLink(self):
        return self.elementClick(self._events_nav_link)
    
    def submitForm(self):
        return self.elementClick(self._submit_form)

    def nameError(self):
        return self.isElementPresent(self._name_error, locatorType='xpath')

    def emailError(self):
        return self.isElementPresent(self._email_error, locatorType='xpath')

    def groupError(self):
        return self.isElementPresent(self._group_error, locatorType='xpath')

    def descriptionError(self):
        return self.isElementPresent(self._description_error, locatorType='xpath')

    def faqDiscount(self):
        return self.elementClick(self._faq_discount, locatorType='xpath')

    def faqPackage(self):
        return self.elementClick(self._faq_packages, locatorType='xpath')

    def faqButton(self):
        return self.elementClick(self._faq_button)

    def verifyFaqPage(self):
        return self.isElementPresent(self._faq_page, locatorType='xpath')

    def goHome(self):
        return self.elementClick(self._home_icon)

    def goBack(self):
        return self.driver.back()

    def verifyBlankForm(self):
        result = self.nameError()
        return result

    def generalEventsCheck(self):
        self.goToEventsPage()
        time.sleep(2)
        self.verifyGroupSize()
        self.verifyEventLocationList()
        time.sleep(2)
        self.submitForm()
        result = self.verifyBlankForm()
        assert result == True
        self.emailError()
        self.groupError()
        self.descriptionError()
        self.NotifySlack('Smoke test finished for https://www.thevoid.com/events/', self.SLACK_SPEAK)
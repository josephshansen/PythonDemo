from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the ralph_links_tests.py are defined. 
"""

class RalphExperience(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
    _choose_ralph_tile = 'buttonBookNow-dimensionCard-dimension-19'
    _home_icon = 'globalNav-link-home'
    _play_video = 'button-dimensionPage-playTrailer'
    _close_video = 'closeVideoLightbox'
    _story_text = '//span[text()="Join arcade game stars Wreck-It Ralph and \
Vanellope von Schweetz to sneak into the internet where you and your friends \
will travel inside the coolest video games. While you’re at it, be sure to \
survive an epic food fight at the Pancake Milkshake Diner."]'
    _experience_link = 'tab-dimensionPage-longDescription'
    _experience_text_one = '//p[text()="It’s time to break into the internet! \
Get ready for Ralph Breaks VR, the immersive virtual adventure by ILMxLAB, The \
VOID, and Walt Disney Animation Studios."]'
    _experience_text_two = '//p[text()="In Ralph Breaks VR, you and up to three \
friends or family will sneak onto the internet alongside Wreck-It Ralph and Vanellope \
von Schweetz. Together you’ll play the newest, coolest video game ever and have \
the ultimate food fight in Pancake Milkshake Diner."]'
    _choose_location = 'button-dimensionPage-chooseLocation'
    _location_list = 'modal-content' #class
    _more_times = 'button-seeMoreTimes-ralph-breaks-vr'
    _eight_pm = 'time-2000'
# After talking to Brian, selenium is selecting the previous vec in the list. So if you want to choose lindon, you have to set it to washington DC's id vec22
    # _santa_anita = 'link-vecId-23' 
    # _san_francisco = 'link-vecId-26' 
    # _santa_monica = 'link-vecId-19' 
    # _atlanta = 'link-vecId-21' 
    # _minneapolis = 'link-vecId-20' 
    # _las_vegas = 'link-vecId-13' 
    # _plano = 'link-vecId-15'
    _orlando = 'link-vecId-9' 
    # _washington_dc = 'link-vecId-22' 
    _edmonton = 'link-vecId-14' 
    _mississauga = 'link-vecId-18' 
    _toronto = 'link-vecId-5' 
    _genting = 'link-vecId-16'
    _choose_time = 'button-timeListItem-1'
    _change_location = 'button-filterLocation'
    _verify_change_location = 'modal-chooseLocationToBook'
    _close_change_location = 'close-nav'
    _contact_link_ralph = 'link-events-contactUs'
    _verify_contact_page = 'fullName'
    _book_now = 'dimensionView-buttonBookNow'
    _book_one_traveler = 'travelerOption-0'
    _checkout_one_traveler = '//span[text()="1 travel pass for"]'
    _checkout_ralph = '//span[text()="Ralph Breaks VR"]'
    _checkout_details = '//p[text()="General Admission (Ages 10+) ($29.95 × 1)"]'
    _checkout_total = '//p[text()="$29.95"]'
    _checkout_tax = '//p[text()="$1.95"]'
    _grand_total = '//p[text()="$31.90"]'
    _experience_tab = 'globalNav-link-experiences'

    def experienceTab(self):
        return self.elementClick(self._experience_tab)

    def goToRalphPage(self):
        return self.elementClick(self._choose_ralph_tile)

    def goHome(self):
        return self.elementClick(self._home_icon)

    def bookNow(self):
        return self.elementClick(self._book_now)

    def bookOneTraveler(self):
        return self.elementClick(self._book_one_traveler)

    def verifyOneTraveler(self):
        return self.isElementPresent(self._checkout_one_traveler, locatorType='xpath')

    def verifyRalphCheckout(self):
        return self.isElementPresent(self._checkout_ralph, locatorType='xpath')

    def verifyCheckoutDetails(self):
        return self.isElementPresent(self._checkout_details, locatorType='xpath')

    def verifyCheckoutTotal(self):
        return self.isElementPresent(self._checkout_total, locatorType='xpath')

    def verifyGrandTotal(self):
        return self.isElementPresent(self._grand_total, locatorType='xpath')

    def playRalphVideo(self):
        return self.elementClick(self._play_video)

    def closeRalphVideo(self):
        return self.elementClick(self._close_video)

    def experienceLink(self):
        return self.elementClick(self._experience_link)

    def chooseLocationLink(self):
        return self.elementClick(self._choose_location)

    def verifyNoLocationLink(self):
        try:
            noLink = self.driver.find_element_by_id(self._choose_location).is_displayed
            if noLink:
                self.log.error("Choose location is available, but it shouldn't be")
            else:
                self.log.info("Choose location isn't available, so it passed")
        except:
            NoSuchElementException
            self.log.info("Except")

    def windowAfter(self):
        window_after = self.driver.window_handles[1]
        return self.driver.switch_to.window(window_after)

    def chooseGenting(self):
        return self.elementClick(self._genting)

    def verifyOrlando(self):
        return self.isElementPresent(self._orlando)

    def chooseOrlando(self):
        return self.elementClick(self._orlando)

    # def chooseWashingtonDC(self):
    #     return self.elementClick(self._washington_dc)

    # def verifySantaAnita(self):
    #     return self.isElementPresent(self._santa_anita)

    # def verifySanFran(self):
    #     return self.isElementPresent(self._san_francisco)

    # def verifySantaMonica(self):
    #     return self.isElementPresent(self._santa_monica)

    # def verifyAtlanta(self):
    #     return self.isElementPresent(self._atlanta)

    # def verifyMinneapolis(self):
    #     return self.isElementPresent(self._minneapolis)

    # def verifyLasVegas(self):
    #     return self.isElementPresent(self._las_vegas)

    # def verifyPlano(self):
    #     return self.isElementPresent(self._plano)

    # def verifyWashingtonDC(self):
    #     return self.isElementPresent(self._washington_dc)

    def verifyEdmonton(self):
        return self.isElementPresent(self._edmonton)

    def verifyMississauga(self):
        return self.isElementPresent(self._mississauga)

    def verifyToronto(self):
        return self.isElementPresent(self._toronto)

    def verifyGenting(self):
        return self.isElementPresent(self._genting)

    def selectTime(self):
        return self.elementClick(self._choose_time)

    def changeLocation(self):
        return self.elementClick(self._change_location)

    def closeChangeLocation(self):
        return self.elementClick(self._close_change_location)

    def ralphContactLink(self):
        return self.elementClick(self._contact_link_ralph)

    def goBack(self):
        return self.driver.back()

    def scrollToTimes(self):
        return self.driver.execute_script("window.scrollTo(500, document.body.scrollHeight);")

    def verifyStoryText(self):
        return self.isElementPresent(self._story_text, locatorType='xpath')

    def verifyExperienceTextOne(self):
        return self.isElementPresent(self._experience_text_one, locatorType='xpath')

    def verifyExperienceTextTwo(self):
        return self.isElementPresent(self._experience_text_two, locatorType='xpath')

    def verifyTimeSelected(self):
        return self.driver.find_element_by_id(self._choose_time).is_selected()

    def verifyLocationLink(self):
        return self.isElementPresent(self._verify_change_location)

    def verifyContactPage(self):
        return self.isElementPresent(self._verify_contact_page)

    def verifyRalphPage(self):
        return self.isElementPresent(self._play_video)

    def clickRalphMoreTimes(self):
        try:
            additionalTimes = self.driver.find_element_by_id('button-seeMoreTimes-ralph-breaks-vr').is_displayed
            if additionalTimes:
                self.elementClick(self._more_times)
                self.log.info('See More Times is Displayed')
                self.elementClick(self._eight_pm)
            else:
                self.log.info('See More Times is Not Displayed')
        except:
            NoSuchElementException
            self.log.info('See More Times is Not Displayed')

    def verifyRalphLocationList(self):
        # self.verifySantaAnita()
        # self.verifySanFran()
        # self.verifySantaMonica()
        # self.verifyAtlanta()
        # self.verifyMinneapolis()
        # self.verifyLasVegas()
        # self.verifyPlano()
        # self.verifyOrlando()
        # self.verifyWashingtonDC()
        # self.verifyEdmonton()
        # self.verifyMississauga()
        # self.verifyToronto()
        self.verifyGenting()

######TESTS######        
    def ralphExperience(self):
        # self.experienceTab()
        # time.sleep(2)
        self.goToRalphPage()
        time.sleep(2)
        self.verifyRalphPage()
        self.playRalphVideo()
        time.sleep(4)
        self.closeRalphVideo()
        time.sleep(2)
        self.verifyStoryText()
        time.sleep(2)
        self.experienceLink()
        time.sleep(2)
        self.verifyExperienceTextOne()
        self.verifyExperienceTextTwo()
        time.sleep(2)
        # self.verifyNoLocationLink()
        self.chooseLocationLink()
        time.sleep(2)
        self.verifyRalphLocationList()
        # time.sleep(2)
        # self.chooseGenting()
        # time.sleep(4)
        # self.scrollToTimes()
        # self.clickRalphMoreTimes()
        # time.sleep(2)
        # self.selectTime()
        # self.verifyTimeSelected()
        # self.changeLocation()
        # time.sleep(2)
        # self.goBack()
        # time.sleep(2)
        # self.chooseLocationLink()
        # time.sleep(2)
        # self.chooseOrlando()
        # time.sleep(4)
        # self.ralphContactLink()
        # time.sleep(2)
        # self.verifyContactPage()
        # self.goBack()
        # time.sleep(2)
        # self.verifyRalphPage()
        # self.chooseLocationLink()
        # time.sleep(2)
        # self.verifyLocationLink()
        # time.sleep(4)
        # self.scrollToTimes()
        # self.selectTime()
        # time.sleep(2)
        # self.bookNow()
        # time.sleep(2)
        # self.bookOneTraveler()
        # time.sleep(4)
        # self.verifyOneTraveler()
        # self.verifyRalphCheckout()
        # self.verifyCheckoutDetails()
        # self.verifyCheckoutTotal()
        # self.verifyGrandTotal()
        # self.goHome()
        self.NotifySlack('Smoke test finished for https://www.thevoid.com/dimensions/ralph-breaks-vr/', self.SLACK_SPEAK)

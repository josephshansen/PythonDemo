from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the homepage_tests.py are defined. 
"""

class HomePage(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
    _main_logo = "brand-logo"
    _main_slogan_one = '//span[text()="Most Immersive Virtual Reality"]'
    _main_slogan_two = "//span[text()='Experience Ever']"
    _home_book_now = "button-bookNow"
    _jumanji_synopsis = '//div[@id="dimensions-list"]//span[text()="The evil Haka’ar has stolen the Scepter of Se’payu containing the Red Jewel of Jumanji! You and your companions must enter the game, take on the form of its heroes and stop Haka’ar from remaking the world into his own! Only you can save Jumanji!"]'
    _jumanji_Card = 'buttonBookNow-dimensionCard-dimension-27'
    _avengers_Card = 'buttonBookNow-dimensionCard-dimension-18'
    _star_wars_Card = 'buttonBookNow-dimensionCard-dimension-14'
    _ralph_Card = 'buttonBookNow-dimensionCard-dimension-19'
    _nico_Card = 'buttonBookNow-dimensionCard-dimension-16'
    _ghostbusters_Card = 'buttonBookNow-dimensionCard-dimension-15'
    _explore_dimension = '#find-your-experience > div > h2'
    _view_faq = "button-viewFaq"
    _jumanji_promo = '//*[@id="button-dimensionPromo-bookNow"]'
    _avengers_promo = '//*[@id="button-dimensionPromo-bookNow"]'
    _jumanjiNewRelease = 'button-dimensionPromo-bookNow'
    _avengersNewRelease = 'button-dimensionPromo-bookNow'
    _events_card = 'button-viewEvents'
    _faq_button = 'button-viewFaq'
    _faq_page = '//span[text()="Frequently Asked Questions"]'
    _gift_card_link = 'button-viewGiftCards'
    _contact_footer = 'footer-link-contact'
    _faq_footer = 'footer-link-faq'
    _gift_card_footer = 'footer-link-giftCards'
    _gift_card_page = 'container'
    _contact_page = 'row'
    _terms_footer = 'footer-link-tos'
    _privacy_footer = 'footer-link-privacyPolicy'
    _youtube_footer = 'footer-link-youTube'
    _instagram_footer = 'footer-link-instagram'
    _twitter_footer = 'footer-link-twitter'
    _facebook_footer = 'footer-link-facebook'
    _filter_location = 'button-filterLocation'
# Filter Locations
    _san_francisco = 'link-vecId-26'
    _verify_SF = '//h2[text()="Filtered by San Francisco, CA"]'
# Review Links:
    _new_York = 'reviewCarousel-sourceLink-1'
    _fast_company = 'reviewCarousel-sourceLink-2'
    _forbes = 'reviewCarousel-sourceLink-3'
    _rolling_stone = 'reviewCarousel-sourceLink-4'
    _polygon = 'reviewCarousel-sourceLink-5'
    _cnet = 'reviewCarousel-sourceLink-6'
    _cnn = 'reviewCarousel-sourceLink-7'
    _venture_beat = 'reviewCarousel-sourceLink-8'
    _variety = 'reviewCarousel-sourceLink-9'
    _carousel_back = 'button-reviewCarousel-prev'
    _carousel_next = 'button-reviewCarousel-next'
# Review Page Verification
    _verify_new_york = '//span[text()="Virtual Reality’s Potential for Magic Gets Real"]'
    _verify_fast_company = '//a[text()="Virtual reality reimagines the haunted mansion–with eerily realistic effects"]'
    _verify_forbes = '//h1[text()="Inside The Void\'s Fully Immersive \'Star Wars\' VR Experience: A Review"]'
    _verify_rolling_stones = '//h3[contains(text(),"Virtual Reality Gets Actually Cool")]'
    _verify_polygon = '//section[text()="The most promising virtual reality experience I\'ve ever had"]'
    _verify_cnet = '//h1[text()="VR needs more Disney-style magic like The Void from CES 2019"]'
    _verify_cnn = '//h1[text()="\'Wreck-It Ralph\' hopes to break virtual reality, too"]'
    _verify_venture_beat = '//h1[text()="Ralph Breaks VR hands-on — Going inside a 3D animated movie at The Void"]'
    _verify_variety = 'post-1202834143'
    _verify_terms = '//h1[text()="The VOID Terms of Service"]'
    _verify_privacy = '//h1[text()="The VOID Privacy Policy"]'
    _verify_youtube = 'subscribe-button'
    _verify_instagram = 'react-root'
    _verify_twitter = '//a[@href="/voidvr/header_photo"]'
    _verify_facebook = 'facebook'
# Notify Card
    _notify_me = 'button-formSubmit-emailSignUpForm'
    _notify_bday_error = '//p[@class="text-error"]//span[text()="Sorry, there’s an age restriction for emails from The VOID."]'
    _notify_email_error = '//p[@class="text-error"]//span[text()="Invalid email address. Check for typos and try again."]'
    _notify_checkbox = 'marketing'
    _notify_bday_field = 'birthdate'
    _notify_email_field = 'email'
    _notify_full_name = 'fullname'
    _notify_success = '//div[@class="form-success"]//span[text()="You’re all set"]'
# Navigation Links
    _experiences_link = 'globalNav-link-experiences'
    _locations_link = 'globalNav-link-locations'
    _events_link = 'globalNav-link-events'
    _void_story = 'globalNav-link-about'
    _join_team = 'globalNav-link-careers'
    _verify_locations_page = "locations-map"
    _verify_events_page = '__next'
    _verify_void_story_page = 'button-aboutPage-playVideo'
    _verify_join_team_page = 'perks'

# Dimension Pages
    _jumanji_vr = 'button-dimensionPage-playTrailer'
    _avengers_vr = 'button-dimensionPage-playTrailer'
    _star_wars_vr = 'button-dimensionPage-playTrailer'
    _ralph_vr = 'button-dimensionPage-playTrailer'
    _nico_vr = 'button-dimensionPage-playTrailer'
    _ghostbusters_vr = 'button-dimensionPage-playTrailer'

    def checkHomeLogo(self):
        return self.isElementPresent(self._main_logo)

    def checkHomeSlogon1(self):
        return self.isElementPresent(self._main_slogan_one, locatorType="xpath")

    def checkHomeSlogon2(self):
        return self.isElementPresent(self._main_slogan_two, locatorType="xpath")

    # def scrollToBookButton(self):
    #     element = self.getElement(self._home_book_now)
    #     actions = ActionChains(self.driver)
    #     actions.move_to_element(element).perform()

    def clickHomeBookNow(self):
        return self.elementClick(self._home_book_now)

    def verifyJumanjiSynopsisText(self):
        return self.isElementPresent(self._jumanji_synopsis, locatorType="xpath")

    def jumanjiViewDetails(self):
        return self.elementClick(self._jumanji_Card)

    def verifyJumanjiVr(self):
        return self.isElementPresent(self._jumanji_vr)

    def verifyAvengersVr(self):
        return self.isElementPresent(self._avengers_vr)

    def verifyStarWarsVr(self):
        return self.isElementPresent(self._star_wars_vr)

    def verifyRalphVr(self):
        return self.isElementPresent(self._ralph_vr)

    def verifyNicoVr(self):
        return self.isElementPresent(self._nico_vr)

    def verifyGhostbustersVr(self):
        return self.isElementPresent(self._ghostbusters_vr)

    def verifyExploreDimension(self):
        return self.elementVisible(self._explore_dimension, locatorType="css")

    def viewFaq(self):
        return self.isElementPresent(self._view_faq)

    def avengersViewDetails(self):
        return self.elementClick(self._avengers_Card)

    def starwarsViewDetails(self):
        return self.elementClick(self._star_wars_Card)

    def ralphViewDetails(self):
        return self.elementClick(self._ralph_Card)

    def nicoViewDetails(self):
        return self.elementClick(self._nico_Card)

    def ghostbustersViewDetails(self):
        return self.elementClick(self._ghostbusters_Card)

    def verifyLocationsPage(self):
        return self.isElementPresent(self._verify_locations_page)

    def verifyEventsPage(self):
        return self.isElementPresent(self._verify_events_page)

    def verifyVoidStoryPage(self):
        return self.isElementPresent(self._verify_void_story_page)

    def verifyJoinTeamPage(self):
        return self.isElementPresent(self._verify_join_team_page)

    def jumanjiNewReleaseBuyNow(self):
        return self.driver.find_elements(By.ID, self._jumanjiNewRelease)[0].click()

    def avengersNewReleaseBuyNow(self):
        return self.driver.find_elements(By.ID, self._avengersNewRelease)[1].click()

    def clickEventsCard(self):
        return self.elementClick(self._events_card)

    def filterLocation(self):
        return self.elementClick(self._filter_location)

    def filterLocationSF(self):
        return self.elementClick(self._san_francisco)

    def verifyLocationSF(self):
        return self.isElementPresent(self._verify_SF, locatorType='xpath')

# Notify Me
    def clickNotifyMe(self):
        return self.elementClick(self._notify_me)

    def verifyNotifyBdayError(self):
        return self.isElementPresent(self._notify_bday_error, locatorType='xpath')

    def verifyNotifyEmailError(self):
        return self.isElementPresent(self._notify_email_error, locatorType='xpath')

    def notifyCheckBox(self):
        return self.checkBoxClick(self._notify_checkbox)

    def notifyCheckBoxClick(self):
        return self.elementClick(self._notify_checkbox)

    def notifyBdayText(self, bday):
        return self.sendKeys(bday, self._notify_bday_field)

    def notifyEmailText(self, email):
        return self.sendKeys(email, self._notify_email_field)

    def notifyNameText(self, name):
        return self.sendKeys(name, self._notify_full_name)

    def verifyNotifySuccess(self):
        return self.isElementPresent(self._notify_success, locatorType='xpath')

# Review links:
    def newYorkTimesLink(self):
        return self.elementClick(self._new_York)

    def verifyNewYorkTimes(self):
        return self.isElementPresent(self._verify_new_york, locatorType='xpath')

    def fastCompanyLink(self):
        return self.elementClick(self._fast_company)

    def verifyFastCompany(self):
        return self.isElementPresent(self._verify_fast_company, locatorType='xpath')
        
    def forbesLink(self):
        return self.elementClick(self._forbes)

    def verifyForbes(self):
        return self.isElementPresent(self._verify_forbes, locatorType='xpath')

    def rollingStoneLink(self):
        return self.elementClick(self._rolling_stone)

    def verifyRollingStone(self):
        return self.isElementPresent(self._verify_rolling_stones, locatorType='xpath')

    def polygonLink(self):
        return self.elementClick(self._polygon)

    def verifyPolygon(self):
        return self.isElementPresent(self._verify_polygon, locatorType='xpath')

    def cnetLink(self):
        return self.elementClick(self._cnet)

    def verifyCnet(self):
        return self.isElementPresent(self._verify_cnet, locatorType='xpath')

    def cnnLink(self):
        return self.elementClick(self._cnn)

    def verifyCnn(self):
        return self.isElementPresent(self._verify_cnn, locatorType='xpath')
        
    def ventureBeatLink(self):
        return self.elementClick(self._venture_beat)

    def verifyVentureBeat(self):
        return self.isElementPresent(self._verify_venture_beat, locatorType='xpath')

    def varietyLink(self):
        return self.elementClick(self._variety)

    def verifyVariety(self):
        return self.isElementPresent(self._verify_variety, locatorType='xpath')
        
# Navigation Links:
    def experiencesLink(self):
        return self.elementClick(self._experiences_link)

    def locationsLink(self):
        return self.elementClick(self._locations_link)

    def eventsLink(self):
        return self.elementClick(self._events_link)

    def voidStory(self):
        return self.elementClick(self._void_story)

    def joinTeam(self):
        return self.elementClick(self._join_team)

# FAQ Link:
    def faqLink(self):
        return self.elementClick(self._faq_button)

    def faqPage(self):
        return self.isElementPresent(self._faq_page, locatorType='xpath')

# Gift Card Link:
    def giftCardLink(self):
        return self.elementClick(self._gift_card_link)

    def giftCardPage(self):
        return self.isElementPresent(self._gift_card_page, locatorType='class')

# Footer links:
    def contactFooter(self):
        return self.elementClick(self._contact_footer)

    def contactPage(self):
        return self.isElementPresent(self._contact_page, locatorType='class')

    def faqFooter(self):
        return self.elementClick(self._faq_footer)

    def giftCardFooter(self):
        return self.elementClick(self._gift_card_footer)

    def termsPage(self):
        return self.elementClick(self._terms_footer)

    def verifyTermsPage(self):
        return self.isElementPresent(self._verify_terms, locatorType='xpath')

    def privacyPage(self):
        return self.elementClick(self._privacy_footer)

    def verifyPrivacyPage(self):
        return self.isElementPresent(self._verify_privacy, locatorType='xpath')

    def youtubePage(self):
        return self.elementClick(self._youtube_footer)

    def verifyYoutube(self):
        return self.isElementPresent(self._verify_youtube)

    def instagramPage(self):
        return self.elementClick(self._instagram_footer)

    def verifyInstagram(self):
        return self.isElementPresent(self._verify_instagram)

    def twitterPage(self):
        return self.elementClick(self._twitter_footer)

    def verifyTwitter(self):
        return self.isElementPresent(self._verify_twitter, locatorType='xpath')

    def facebookPage(self):
        return self.elementClick(self._facebook_footer)

    def verifyFacebook(self):
        return self.isElementPresent(self._verify_facebook)

# General element uses
    def goBack(self):
        return self.driver.back()

    # def scrollToTop(self):
    #     return self.driver.find_element_by_tag_name('body').send_keys(Keys.CONTROL + Keys.HOME)

    def scrollToBottom(self):
        return self.driver.find_element_by_tag_name('body').send_keys(Keys.CONTROL + Keys.END)

    def windowBefore(self):
        window_before = self.driver.window_handles[0]
        return self.driver.switch_to.window(window_before)

    def windowAfter(self):
        window_after = self.driver.window_handles[1]
        return self.driver.switch_to.window(window_after)

    def closeWindow(self):
        return self.driver.close()

    def carouselBack(self):
        return self.elementClick(self._carousel_back)

    def carouselNext(self):
        return self.elementClick(self._carousel_next)

    # def carouselNextTwo(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 3
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(4)

    # def carouselNextThree(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 4
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(2)

    # def carouselNextFour(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 5
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(2)

    # def carouselNextFive(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 6
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(2)

    # def carouselNextSix(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 7
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(2)

    # def carouselNextSeven(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 8
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(2)

    # def carouselNextEight(self):
    #     button = self.elementClick(self._carousel_next)
    #     count = 9
    #     while count > 1:
    #         button.click()
    #         count -= 1
    #         time.sleep(2)

# Final Test
    def homePageLoads(self):
# Check elements on homepage and jumanji synopsis
        time.sleep(2)
        self.checkHomeLogo()
        self.checkHomeSlogon1()
        self.checkHomeSlogon2()
        self.clickHomeBookNow()
        time.sleep(2)
        self.verifyExploreDimension()

    def verifyJumanjiSynopsis(self):
        result = self.verifyJumanjiSynopsisText()
        return result

# Verify Jumanji page pulls up then go back to the homepage
    def jumanjiTileLink(self):
        self.jumanjiViewDetails()
        time.sleep(2)
        self.verifyJumanjiVr()
        self.goBack()
        self.checkHomeLogo()

# Verify experience link works
        self.clickHomeBookNow()
        time.sleep(2)

# Verify location link works and page pulls up
        self.locationsLink()
        self.log.info("Waiting For Location Pages")
        time.sleep(2)
        self.verifyLocationsPage()
        self.goBack()
        self.checkHomeLogo()

# Verify events link works and page pulls up
        self.eventsLink()
        time.sleep(2)
        self.verifyEventsPage()
        self.goBack()
        self.checkHomeLogo()

# Verify Void Story link works and page pulls up
        self.voidStory()
        time.sleep(2)
        self.verifyVoidStoryPage()
        self.goBack()
        self.checkHomeLogo()

# Verify join team link works and page pulls
        self.joinTeam()
        time.sleep(2)
        self.windowAfter()
        self.verifyJoinTeamPage()
        self.closeWindow()
        self.windowBefore()
        self.checkHomeLogo()

# Verify Avengers page pulls up then go back to the homepage
        self.avengersViewDetails()
        time.sleep(2)
        self.verifyAvengersVr()
        self.goBack()
        self.checkHomeLogo()

# Verify Star Wars page pulls up then go back to the homepage
        self.starwarsViewDetails()
        time.sleep(2)
        self.verifyStarWarsVr()
        self.goBack()
        self.checkHomeLogo()

# Verify Ralph page pulls up then go back to the homepage
        self.ralphViewDetails()
        time.sleep(2)
        self.verifyRalphVr()
        self.goBack()
        self.checkHomeLogo()

# Verify Nico page pulls up then go back to the homepage
        self.nicoViewDetails()
        time.sleep(2)
        self.verifyNicoVr()
        self.goBack()
        self.checkHomeLogo()

# Verify Jumanji page pulls up then go back to the homepage
        self.ghostbustersViewDetails()
        time.sleep(2)
        self.verifyGhostbustersVr()
        self.goBack()
        self.checkHomeLogo()

# Click New Releases and verify correct page pulls up
        self.jumanjiNewReleaseBuyNow()
        time.sleep(2)
        self.verifyJumanjiVr()
        self.goBack()
        self.checkHomeLogo()
    
    def verifyHomePage(self):
        result = self.checkHomeLogo()
        return result

# Notify Me
    def verifyNotificationSent(self):
        self.clickNotifyMe()
        self.verifyNotifyBdayError()
        self.verifyNotifyEmailError()
        self.notifyCheckBox()
    #     self.notifyBdayText(bday)
    #     self.notifyEmailText(email)
    #     self.notifyNameText(name)
    #     self.clickNotifyMe()
    #     time.sleep(4)

    # def verifyNotificationSuccess(self):
    #     result = self.verifyNotifySuccess()
    #     return result

    def verifyEventsLink(self):
        time.sleep(2)
        self.clickEventsCard()
        time.sleep(2)
        self.verifyEventsPage()
        self.goBack()
        self.checkHomeLogo()

# FAQ Check
        self.faqLink()
        time.sleep(2)
        self.faqPage()
        self.goBack()
        self.checkHomeLogo()

# Gift Card Check
        self.giftCardLink()
        time.sleep(2)
        self.giftCardPage()
        self.goBack()
        time.sleep(2)

# Footer Links
        self.contactFooter()
        time.sleep(2)
        self.contactPage()
        self.goBack()
        time.sleep(2)
        self.faqFooter()
        time.sleep(2)
        self.faqPage()
        self.goBack()
        self.giftCardFooter()
        time.sleep(2)
        self.giftCardPage()
        self.goBack()
        time.sleep(3)
        self.scrollToBottom()
        time.sleep(4)

#Review Link Check
        self.newYorkTimesLink()
        time.sleep(2)
        self.verifyNewYorkTimes()
        self.goBack()
        time.sleep(2)
        self.carouselNext()
        self.fastCompanyLink()
        time.sleep(2)
        self.verifyFastCompany()
        self.goBack()
        time.sleep(2)
        # self.carouselNextTwo()
        # self.forbesLink()
        # time.sleep(2)
        # self.verifyForbes()
        # self.goBack()
        # self.carouselNextThree()
        # self.rollingStoneLink()
        # time.sleep(2)
        # self.verifyRollingStone()
        # self.goBack()
        # self.carouselNextFour()
        # self.polygonLink()
        # time.sleep(2)
        # self.verifyPolygon()
        # self.goBack()
        # self.carouselNextFive()
        # self.cnetLink()
        # time.sleep(2)
        # self.verifyCnet()
        # self.goBack()
        # self.carouselNextSix()
        # self.cnnLink()
        # time.sleep(2)
        # self.verifyCnn()
        # self.goBack()
        # self.carouselNextSeven()
        # self.ventureBeatLink()
        # time.sleep(2)
        # self.verifyVentureBeat()
        # self.goBack()
        # self.carouselNextEight()
        # self.varietyLink()
        # time.sleep(2)
        # self.verifyVariety()
        # self.goBack()

# Verify Footer Links
        self.termsPage()
        time.sleep(2)
        self.verifyTermsPage()
        self.goBack()
        time.sleep(2)
        self.privacyPage()
        time.sleep(2)
        self.verifyPrivacyPage()
        self.goBack()
        time.sleep(2)
        self.youtubePage()
        self.windowAfter()
        time.sleep(2)
        self.verifyYoutube()
        self.closeWindow()
        self.windowBefore()
        self.instagramPage()
        self.windowAfter()
        time.sleep(2)
        self.verifyInstagram()
        self.closeWindow()
        self.windowBefore()
        self.twitterPage()
        self.windowAfter()
        time.sleep(2)
        self.verifyTwitter()
        self.closeWindow()
        self.windowBefore()
        self.facebookPage()
        self.windowAfter()
        time.sleep(2)
        self.verifyFacebook()
        self.closeWindow()
        self.windowBefore()

        self.filterLocation()
        time.sleep(2)
        self.filterLocationSF()
        time.sleep(2)
        self.verifyLocationSF()
        self.goBack()
        self.NotifySlack('Smoke test finished for homepage https://www.thevoid.com/', self.SLACK_SPEAK)
from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the avengers_pass_tests.py are defined. 
"""

class AvengersBookings(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
    _choose_avengers_tile = 'buttonBookNow-dimensionCard-dimension-18'
    _home_icon = 'globalNav-link-home'
    _play_video = 'button-dimensionPage-playTrailer'
    _close_video = 'closeVideoLightbox'
    _story_text = '//span[text()="Shuri has recruited your team to test a \
powerful new prototype design combining Wakandan and Stark technologies. \
When an enemy from the past seeks to steal the technology, you\'ll fight \
alongside some of your favorite Avengers like Doctor Strange, Wasp, Ant-Man \
and more to stop the attack before they unleash an oppressive new age upon the world."]'
    _experience_link = 'tab-dimensionPage-longDescription'
    _experience_text = '//p[text()="Assemble alongside Earth\'s Mightiest \
Heroes in Avengers: Damage Control, an all-new virtual reality adventure from \
Marvel Studios and ILMxLAB. Shuri has recruited your team of four to test her \
latest prototype design, a powerful new suit that combines Wakandan and Stark \
Industries technologies. When a familiar enemy from the Avengers\' past seeks \
to steal the technology for themselves, your team must stop them before they \
unleash an oppressive new age upon the planet. Fight alongside some of your \
favorite Avengers like Doctor Strange, Wasp, Ant-Man, and more in a race to protect \
the world. Suit up, step in, and save the world in the ultimate Marvel Studios \
immersive experience. Available exclusively for a limited time at The VOID."]'
    _choose_location = 'button-dimensionPage-chooseLocation'
    _location_list = 'modal-content' #class
    _more_times = 'button-seeMoreTimes-marvel-avengers-vr'
    _anaheim = 'link-vecId-10'
    _santa_anita = 'link-vecId-23' 
    _glendale = 'link-vecId-12'
    _san_francisco = 'link-vecId-26' 
    _santa_monica = 'link-vecId-19' 
    _atlanta = 'link-vecId-21' 
    _minneapolis = 'link-vecId-20' 
    _las_vegas = 'link-vecId-13' 
    _plano = 'link-vecId-15' 
    _lindon = 'link-vecId-2'
    _washington_dc = 'link-vecId-22' 
    _edmonton = 'link-vecId-14' 
    _mississauga = 'link-vecId-18' 
    _toronto = 'link-vecId-5' 
    _choose_time = 'button-timeListItem-1'
    _change_location = 'button-filterLocation'
    _verify_change_location = 'modal-chooseLocationToBook'
    _close_change_location = 'close-nav'
    _contact_link_avengers = 'link-events-contactUs'
    _verify_contact_page = 'fullName'
    _book_now = 'dimensionView-buttonBookNow'
    _book_two_travelers = 'travelerOption-1'
    _checkout_two_travelers = '//span[text()="2 travel passes for"]'
    _checkout_avengers = '//span[text()="Avengers"]'
    _checkout_details = '//p[text()="General Admission (Ages 10+) ($0.00 × 2)"]'
    _checkout_total = '//p[text()="$0.00"]'
    _checkout_tax = '//p[text()="$0.00"]'
    _grand_total = '//p[text()="$0.00"]'
    _full_name = 'fullName'
    _email = 'email'
    _legal_checkbox = 'legalCheckbox'
    _submit_payment = 'button-formSubmit-'
    _verify_purchase_successful = 'button-travelPass-claimPass-1'

    def enterName(self, name):
        return self.sendKeys(name, self._full_name)

    def enterEmail(self, email):
        return self.sendKeys(email, self._email)

    def legalCheckbox(self):
        return self.elementClick(self._legal_checkbox)

    def submitPayment(self):
        return self.elementClick(self._submit_payment)

    def verifyPurchaseSuccess(self):
        return self.isElementPresent(self._verify_purchase_successful)

    def goToAvengersPage(self):
        return self.elementClick(self._choose_avengers_tile)

    def goHome(self):
        return self.elementClick(self._home_icon)

    def bookNow(self):
        return self.elementClick(self._book_now)

    def bookTwoTravelers(self):
        return self.elementClick(self._book_two_travelers)

    def verifyTwoTravelers(self):
        return self.isElementPresent(self._checkout_two_travelers, locatorType='xpath')

    def verifyAvengersCheckout(self):
        return self.isElementPresent(self._checkout_avengers, locatorType='xpath')

    def verifyCheckoutDetails(self):
        return self.isElementPresent(self._checkout_details, locatorType='xpath')

    def verifyCheckoutTotal(self):
        return self.isElementPresent(self._checkout_total, locatorType='xpath')

    def verifyGrandTotal(self):
        return self.isElementPresent(self._grand_total, locatorType='xpath')

    def playAvengersVideo(self):
        return self.elementClick(self._play_video)

    def closeAvengersVideo(self):
        return self.elementClick(self._close_video)

    def experienceLink(self):
        return self.elementClick(self._experience_link)

    def chooseLocationLink(self):
        return self.elementClick(self._choose_location)

    def windowAfter(self):
        window_after = self.driver.window_handles[1]
        return self.driver.switch_to.window(window_after)

    def chooseLindon(self):
        return self.elementClick(self._lindon)

    def chooseWashingtonDC(self):
        return self.elementClick(self._washington_dc)

    def verifyAnaheim(self):
        return self.isElementPresent(self._anaheim)

    def verifyGlendale(self):
        return self.isElementPresent(self._glendale)

    def verifySantaAnita(self):
        return self.isElementPresent(self._santa_anita)

    def verifySanFran(self):
        return self.isElementPresent(self._san_francisco)

    def verifySantaMonica(self):
        return self.isElementPresent(self._santa_monica)

    def verifyAtlanta(self):
        return self.isElementPresent(self._atlanta)

    def verifyMinneapolis(self):
        return self.isElementPresent(self._minneapolis)

    def verifyLasVegas(self):
        return self.isElementPresent(self._las_vegas)

    def verifyPlano(self):
        return self.isElementPresent(self._plano)

    def verifyLindon(self):
        return self.isElementPresent(self._lindon)

    def verifyWashingtonDC(self):
        return self.isElementPresent(self._washington_dc)

    def verifyEdmonton(self):
        return self.isElementPresent(self._edmonton)

    def verifyMississauga(self):
        return self.isElementPresent(self._mississauga)

    def verifyToronto(self):
        return self.isElementPresent(self._toronto)

    def selectTime(self):
        return self.elementClick(self._choose_time)

    def changeLocation(self):
        return self.elementClick(self._change_location)

    def closeChangeLocation(self):
        return self.elementClick(self._close_change_location)

    def avengersContactLink(self):
        return self.elementClick(self._contact_link_avengers)

    def goBack(self):
        return self.driver.back()

    def scrollToTimes(self):
        return self.driver.execute_script("window.scrollTo(500, document.body.scrollHeight);")

    def verifyStoryText(self):
        return self.isElementPresent(self._story_text, locatorType='xpath')

    def verifyExperienceText(self):
        return self.isElementPresent(self._experience_text, locatorType='xpath')

    def verifyTimeSelected(self):
        return self.driver.find_element_by_id(self._choose_time).is_selected()

    def verifyLocationLink(self):
        return self.isElementPresent(self._verify_change_location)

    def verifyContactPage(self):
        return self.isElementPresent(self._verify_contact_page)

    def verifyAvengersPage(self):
        return self.isElementPresent(self._play_video)

    def clickAvengersMoreTimes(self):
        try:
            additionalTimes = self.driver.find_element_by_id('button-seeMoreTimes-marvel-avengers-vr').is_displayed
            if additionalTimes:
                self.elementClick(self._more_times)
                self.log.info('See More Times is Displayed')
                self.elementClick(self._eight_pm)
            else:
                self.log.info('See More Times is Not Displayed')
        except:
            NoSuchElementException
            self.log.info('See More Times is Not Displayed')

######TESTS######        
    def avengersTwoBookings(self, name, email):
        self.goToAvengersPage()
        time.sleep(2)
        self.verifyAvengersPage()
        self.chooseLocationLink()
        time.sleep(2)
        self.chooseWashingtonDC()
        time.sleep(4)
        self.scrollToTimes()
        self.selectTime()
        self.verifyTimeSelected()
        time.sleep(2)
        self.bookNow()
        time.sleep(2)
        self.bookTwoTravelers()
        time.sleep(4)
        self.verifyTwoTravelers()
        self.verifyAvengersCheckout()
        self.verifyCheckoutDetails()
        self.verifyCheckoutTotal()
        self.verifyGrandTotal()
        self.enterName(name)
        self.enterEmail(email)
        self.legalCheckbox()
        self.submitPayment()
        time.sleep(6)
        self.verifyPurchaseSuccess()
        self.goHome()


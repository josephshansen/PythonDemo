from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the locations_tests.py are defined. 
"""

class LocationsPage(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
# Location Links
    _locations_link = 'globalNav-link-locations'
    _home_icon = 'globalNav-link-home'
    _santa_monica = 'link-view-santa-monica'
    _san_francisco = 'link-view-virtual-reality-san-francisco'
    _santa_anita = 'link-view-virtual-reality-arcadia'
    _anaheim = 'link-view-anaheim-downtown-disney'
    _glendale = 'link-view-los-angeles-glendale'
    _orlando = 'link-view-disney-springs-orlando'
    _atlanta = 'link-view-vr-atlanta'
    _minneapolis = 'link-view-virtual-reality-minneapolis'
    _las_vegas = 'link-view-virtual-reality-las-vegas'
    _new_york = 'link-view-nyc-vr'
    _plano = 'link-view-west-plano-cinemark'
    _washington = 'link-view-washington-dc'
    _edmonton = 'link-view-edmonton-canada'
    _toronto = 'link-view-vr-toronto'
    _mississauga = 'link-view-vr-mississauga'
    _genting = 'link-view-pahang-malaysia-genting'
    _dubai = 'link-view-dubai'
    _covid = '(385) 323-0090'
# Verify Location Pages
    _verify_santa_monica = '//span[text()="The VOID Santa Monica"]'
    _verify_sf = '//span[text()="The VOID San Francisco"]'
    _verify_santa_anita = '//span[text()="The VOID at Santa Anita | Arcadia"]'
    _verify_anaheim = '//span[text()="The VOID Downtown Disney®"]'
    _verify_glendale = '//span[text()="The VOID at Glendale Galleria"]'
    _verify_orlando = '//span[text()="The VOID at Disney Springs®"]'
    _verify_atlanta = '//span[text()="The VOID at The Battery Atlanta"]'
    _verify_minneapolis = '//span[text()="The VOID Minneapolis | Mall of America"]'
    _verify_las_vegas = '//span[text()="The VOID at Grand Canal Shoppes | Las Vegas"]'
    _verify_new_york = '//span[text()="The VOID NYC"]'
    _verify_plano = '//span[text()="The VOID at Cinemark West Plano"]'
    _verify_washington = '//span[text()="The VOID Washington, DC | Tysons Corner"]'
    _verify_edmonton = '//span[text()="The VOID Edmonton | Rec Room"]'
    _verify_toronto = '//span[text()="The VOID Toronto"]'
    _verify_mississauga = '//span[text()="The VOID Mississauga"]'
    _verify_genting = '//span[text()="The VOID Genting"]'
    _verify_dubai = '//span[text()="The VOID Dubai"]'
    _map = 'locationMap'
    _directions = 'button-locationsPage-getDirections'
    _avengers = '//span[text()="Avengers"]'
    _jumanji = '//span[text()="Jumanji"]'
    _star_wars = '//span[text()="Star Wars™"]'
    _ralph = '//span[text()="Ralph Breaks VR"]'
    _nico = '//span[text()="Nicodemus"]'
    _ghostbusters = '//span[text()="Ghostbusters"]'
    _no_experiences = '//p[contains(text(), "There are currently no available experiences at")]'
    _temp_closed = '//p[text()="Temporarily Closed"]'
# Orlando Location Info:
    _orlando_hours_one = '//p[text()="12pm - 9pm | Sun - Thu"]'
    _orlando_hours_two = '//p[text()="12pm - 10pm | Fri - Sat"]'
    _orlando_address = '//a[contains(text(), "1732 E Buena Vista Dr")]'
# General Contact Info:
    _email = 'support@thevoid.com'
# Anaheim Info:
    _anaheim_address = '//a[contains(text(), "1580 S Disneyland Dr")]'
# Glendale Info:
    _glendale_address = '//a[contains(text(), "1164 Galleria Way")]'
# SF Info:
    _sf_address = '//a[contains(text(), "865 Market St")]'
    _sf_email = 'sanfrancisco-leads@thevoid.com'
# Santa Anita:
    _sa_address = '//a[contains(text(), "400 S Baldwin Ave")]'
    _sa_email = 'arcadia-leads@thevoid.com'
# Santa Monica:
    _sm_address = '//a[contains(text(), "1220 3rd Street")]'
# Atlanta:
    _atlanta_address = '//a[contains(text(), "800 Battery Ave. #120")]'
    _atlanta_hours = '//p[text()="10am - 10pm daily"]'
# Minneapolis:
    _minneapolis_address = '//a[contains(text(), "Mall of America")]'
# Las Vegas:
    _LV_address = '//a[contains(text(), "3377 S. Las Vegas Blvd #2235")]'
# NY:
    _ny_address = '//a[contains(text(), "185 Greenwich St")]'
# Plano:
    _plano_address = '//a[contains(text(), "Cinemark West Plano and XD")]'
    _plano_email = '5231@cinemark.com'
# DC:
    _dc_address = '//a[contains(text(), "7866L Tysons Corner Center")]'
# Edmonton:
    _edmonton_address = '//a[contains(text(), "West Edmonton Mall, Unit 2065")]'
# Toronto:
    _toronton_address = '//a[contains(text(), "255 Bremner Blvd")]'
    _toronto_email = 'Info.toronto@therecroom.com'
# Mississauga:
    _mississauga_address = '//a[contains(text(), "100 City Centre Drive")]'
    _mississauga_email = 'GamereservationsSQ1@therecroom.com'
# Genting:
    _genting_address = '//a[contains(text(), "Genting Highlands")]'
    _genting_hours_one = '//p[text()="Fri - Sat | 10am - 10pm"]'
    _genting_hours_two = '//p[text()="Sun - Thu | 12pm - 8pm"]'
# Dubai:
    _dubai_address = '//a[contains(text(), "Hub Zero, City Walk")]'

    def covidNumber(self):
        return self.isElementPresent(self._covid, locatorType='link')

    def goHome(self):
        return self.elementClick(self._home_icon)

    def locationClosed(self):
        return self.isElementPresent(self._temp_closed, locatorType='xpath')
    
    def getLocationsPage(self):
        return self.elementClick(self._locations_link)

    def santaMonicaLink(self):
        return self.elementClick(self._santa_monica)
    
    def sfLink(self):
        return self.elementClick(self._san_francisco)

    def santaAnitaLink(self):
        return self.elementClick(self._santa_anita)

    def anaheimLink(self):
        return self.elementClick(self._anaheim)

    def glendaleLink(self):
        return self.elementClick(self._glendale)

    def orlandoLink(self):
        return self.elementClick(self._orlando)

    def atlantaLink(self):
        return self.elementClick(self._atlanta)

    def minneapolisLink(self):
        return self.elementClick(self._minneapolis)

    def lasVegasLink(self):
        return self.elementClick(self._las_vegas)

    def newYorkLink(self):
        return self.elementClick(self._new_york)

    def planoLink(self):
        return self.elementClick(self._plano)

    def washingtonLink(self):
        return self.elementClick(self._washington)

    def edmontonLink(self):
        return self.elementClick(self._edmonton)

    def torontoLink(self):
        return self.elementClick(self._toronto)

    def mississaugaLink(self):
        return self.elementClick(self._mississauga)

    def gentingLink(self):
        return self.elementClick(self._genting)

    def dubaiLink(self):
        return self.elementClick(self._dubai)

    def goBack(self):
        return self.driver.back()

    def jumanji(self):
        return self.isElementPresent(self._jumanji, locatorType='xpath')

    def avengers(self):
        return self.isElementPresent(self._avengers, locatorType='xpath')

    def starWars(self):
        return self.isElementPresent(self._star_wars, locatorType='xpath')

    def ralph(self):
        return self.isElementPresent(self._ralph, locatorType='xpath')

    def nico(self):
        return self.isElementPresent(self._nico, locatorType='xpath')

    def ghostbusters(self):
        return self.isElementPresent(self._ghostbusters, locatorType='xpath')

    def noExperiences(self):
        return self.isElementPresent(self._no_experiences, locatorType='xpath')

# Verify Location Pages
    def verifySantaMonica(self):
        self.isElementPresent(self._verify_santa_monica, locatorType='xpath')
        self.isElementPresent(self._sm_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifySanFran(self):
        self.isElementPresent(self._verify_sf, locatorType='xpath')
        self.isElementPresent(self._sf_address, locatorType='xpath')
        self.isElementPresent(self._sf_email, locatorType='link')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifySantaAnita(self):
        self.isElementPresent(self._verify_santa_anita, locatorType='xpath')
        self.isElementPresent(self._sa_address, locatorType='xpath')
        self.isElementPresent(self._sa_email, locatorType='link')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifyAnaheim(self):
        self.isElementPresent(self._verify_anaheim, locatorType='xpath')
        self.isElementPresent(self._anaheim_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.avengers()
        # self.starWars()

    def verifyGlendale(self):
        self.isElementPresent(self._verify_glendale, locatorType='xpath')
        self.isElementPresent(self._glendale_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.avengers()
        # self.starWars()
        # self.ghostbusters()

    def verifyOrlando(self):
        self.isElementPresent(self._verify_orlando, locatorType='xpath')
        self.isElementPresent(self._orlando_address, locatorType='xpath')
        # self.isElementPresent(self._orlando_hours_one, locatorType='xpath')
        # self.isElementPresent(self._orlando_hours_two, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.starWars()
        # self.ralph()

    def verifyAtlanta(self):
        self.isElementPresent(self._verify_atlanta, locatorType='xpath')
        self.isElementPresent(self._atlanta_address, locatorType='xpath')
        # self.isElementPresent(self._atlanta_hours, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()
        # self.ghostbusters()

    def verifyMinneapolis(self):
        self.isElementPresent(self._verify_minneapolis, locatorType='xpath')
        self.isElementPresent(self._minneapolis_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifyLasVegas(self):
        self.isElementPresent(self._verify_las_vegas, locatorType='xpath')
        self.isElementPresent(self._LV_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifyNewYork(self):
        self.isElementPresent(self._verify_new_york, locatorType='xpath')
        self.isElementPresent(self._ny_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()

    def verifyPlano(self):
        self.isElementPresent(self._verify_plano, locatorType='xpath')
        self.isElementPresent(self._plano_address, locatorType='xpath')
        self.isElementPresent(self._plano_email, locatorType='link')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifyWashington(self):
        self.isElementPresent(self._verify_washington, locatorType='xpath')
        self.isElementPresent(self._dc_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()

    def verifyEdmonton(self):
        self.isElementPresent(self._verify_edmonton, locatorType='xpath')
        self.isElementPresent(self._edmonton_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()
        # self.ralph()
        # self.nico()

    def verifyToronto(self):
        self.isElementPresent(self._verify_toronto, locatorType='xpath')
        self.isElementPresent(self._toronton_address, locatorType='xpath')
        self.isElementPresent(self._toronto_email, locatorType='link')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()
        # self.ralph()
        # self.nico()

    def verifyMississauga(self):
        self.isElementPresent(self._verify_mississauga, locatorType='xpath')
        self.isElementPresent(self._mississauga_address, locatorType='xpath')
        self.isElementPresent(self._mississauga_email, locatorType='link')
        self.locationClosed()
        self.noExperiences()
        # self.jumanji()
        # self.avengers()
        # self.starWars()
        # self.ralph()
        # self.nico()

    def verifyGenting(self):
        self.isElementPresent(self._verify_genting, locatorType='xpath')
        self.isElementPresent(self._genting_address, locatorType='xpath')
        self.isElementPresent(self._genting_hours_one, locatorType='xpath')
        self.isElementPresent(self._genting_hours_two, locatorType='xpath')
        self.isElementPresent(self._email, locatorType='link')
        # self.locationClosed()
        # self.noExperiences()
        self.avengers()
        self.starWars()
        self.ralph()
        self.nico()
        self.ghostbusters()

    def verifyDubai(self):
        self.isElementPresent(self._verify_dubai, locatorType='xpath')
        self.isElementPresent(self._dubai_address, locatorType='xpath')
        self.locationClosed()
        self.noExperiences()

# Test
    def locationsTest(self): 
        self.getLocationsPage()
        time.sleep(2)
        self.anaheimLink()
        time.sleep(2)      
        self.verifyAnaheim()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.glendaleLink()
        time.sleep(2)
        self.verifyGlendale()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.sfLink()
        time.sleep(2)
        self.verifySanFran()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.santaAnitaLink()
        time.sleep(2)
        self.verifySantaAnita()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.santaMonicaLink()
        time.sleep(2)
        self.verifySantaMonica()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.orlandoLink()
        time.sleep(2)
        self.verifyOrlando()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.atlantaLink()
        time.sleep(2)
        self.verifyAtlanta()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.minneapolisLink()
        time.sleep(2)
        self.verifyMinneapolis()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.lasVegasLink()
        time.sleep(2)
        self.verifyLasVegas()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.newYorkLink()
        time.sleep(2)
        self.verifyNewYork()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.planoLink()
        time.sleep(2)
        self.verifyPlano()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.washingtonLink()
        time.sleep(2)
        self.verifyWashington()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.edmontonLink()
        time.sleep(2)
        self.verifyEdmonton()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.torontoLink()
        time.sleep(2)
        self.verifyToronto()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.mississaugaLink()
        time.sleep(2)
        self.verifyMississauga()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.gentingLink()
        time.sleep(2)
        self.verifyGenting()
        self.covidNumber()
        self.goBack()
        time.sleep(2)
        self.dubaiLink()
        time.sleep(2)
        self.verifyDubai()
        self.covidNumber()
        self.NotifySlack('Smoke test finished for https://www.thevoid.com/locations/', self.SLACK_SPEAK)
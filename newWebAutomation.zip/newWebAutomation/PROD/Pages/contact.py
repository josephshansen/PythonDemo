from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
import requests
coloredlogs.install()

"""
This is where all elements for the contact_tests.py are defined. 
"""

class ContactPage(SeleniumDriver):

    SLACK_SPEAK = 0

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

#Locators
    _contact_synopsis = '//span[text()="Please let us know how we can help you Step Beyond Reality or provide exceptional support after your visit!"]'
    _submit_form = 'button-formSubmit-contactForm'
    _name_error = '//span[text()="Please enter your first and last name."]'
    _email_error = '//span[text()="Invalid email address. Check for typos and try again."]'
    _category_error = '//span[text()="Please select an option."]'
    _description_error = '//span[text()="Please let us know what you’re reaching out for."]'
    _location_button = 'button-contactPage-chooseLocation'
    _verify_location_modal = 'modal-chooseLocation'
    _select_santa_anita = 'link-vecId-23'
    _verify_sa_email = 'arcadia-leads@thevoid.com'
    _employment_email = 'employmentverification@thevoid.com'
    _press_email = 'press@thevoid.com'
    _contact_phone = '(385) 323-0090'
    _home_icon = 'globalNav-link-home'
    _contact_link = 'footer-link-contact'
    _location_list = 'location'
    _anaheim = 'formSelect-option-1'
    _atlanta = 'formSelect-option-2'
    _dubai = 'formSelect-option-3'
    _edmonton = 'formSelect-option-4'
    _genting = 'formSelect-option-5'
    _glendale = 'formSelect-option-6'
    _las_vegas = 'formSelect-option-7'
    _minneapolis = 'formSelect-option-8'
    _mississauga = 'formSelect-option-9'
    _new_york = 'formSelect-option-10'
    _orlando = 'formSelect-option-11'
    _plano = 'formSelect-option-12'
    _san_francisco = 'formSelect-option-13'
    _santa_anita = 'formSelect-option-14'
    _santa_monica = 'formSelect-option-15'
    _toronto = 'formSelect-option-16'
    _washington_dc = 'formSelect-option-17'
    _category = 'category'
    _business_development = 'formSelect-option-1'
    _events = 'formSelect-option-2'
    _press_and_media = 'formSelect-option-3'
    _support = 'formSelect-option-4'

    def verifyContactCategory(self):
        self.elementClick(self._category)
        self.isElementPresent(self._business_development)
        self.isElementPresent(self._events)
        self.isElementPresent(self._press_and_media)
        self.isElementPresent(self._support)
        self.elementClick(self._category)

    def verifyContactLocationList(self):
        self.elementClick(self._location_list)
        self.isElementPresent(self._anaheim)
        self.isElementPresent(self._atlanta)
        self.isElementPresent(self._dubai)
        self.isElementPresent(self._edmonton)
        self.isElementPresent(self._genting)
        self.isElementPresent(self._glendale)
        self.isElementPresent(self._las_vegas)
        self.isElementPresent(self._minneapolis)
        self.isElementPresent(self._mississauga)
        self.isElementPresent(self._new_york)
        self.isElementPresent(self._orlando)
        self.isElementPresent(self._plano)
        self.isElementPresent(self._san_francisco)
        self.isElementPresent(self._santa_anita)
        self.isElementPresent(self._santa_monica)
        self.isElementPresent(self._toronto)
        self.isElementPresent(self._washington_dc)
        self.elementClick(self._location_list)

    def goToContactPage(self):
        return self.elementClick(self._contact_link)

    def verifySynopsis(self):
        return self.elementClick(self._contact_synopsis)
    
    def submitForm(self):
        return self.elementClick(self._submit_form)

    def nameError(self):
        return self.isElementPresent(self._name_error, locatorType='xpath')

    def emailError(self):
        return self.isElementPresent(self._email_error, locatorType='xpath')

    def categoryError(self):
        return self.isElementPresent(self._category_error, locatorType='xpath')

    def descriptionError(self):
        return self.isElementPresent(self._description_error, locatorType='xpath')

    def locationButton(self):
        return self.elementClick(self._location_button)

    def verifyLocationModal(self):
        return self.isElementPresent(self._verify_location_modal)

    def chooseSantaAnita(self):
        return self.elementClick(self._select_santa_anita)

    def verifySantaAnitaEmail(self):
        return self.isElementPresent(self._verify_sa_email, locatorType='link')

    def verifyEmploymentEmail(self):
        return self.isElementPresent(self._employment_email, locatorType='link')

    def verifyPressEmail(self):
        return self.isElementPresent(self._press_email, locatorType='link')

    def verifyPhone(self):
        return self.isElementPresent(self._contact_phone, locatorType='link')

    def goHome(self):
        return self.elementClick(self._home_icon)

    def goBack(self):
        return self.driver.back()

    def verifyBlankForm(self):
        result = self.nameError()
        return result

    def generalContactCheck(self):
        self.goToContactPage()
        time.sleep(2)
        self.verifyContactCategory()
        self.verifyContactLocationList()
        time.sleep(2)
        self.submitForm()
        result = self.verifyBlankForm()
        assert result == True
        self.emailError()
        self.categoryError()
        self.descriptionError()
        self.verifyEmploymentEmail()
        self.verifyPressEmail()
        self.verifyPhone()
        self.locationButton()
        time.sleep(2)
        self.verifyLocationModal()
        self.chooseSantaAnita()
        time.sleep(2)
        self.verifySantaAnitaEmail()
        self.NotifySlack('Smoke test finished for https://www.thevoid.com/events/', self.SLACK_SPEAK)
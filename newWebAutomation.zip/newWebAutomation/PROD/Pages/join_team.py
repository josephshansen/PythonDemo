from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the join_team_tests.py are defined. 
"""

class JoinTeam(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
    _join_team_nav = 'globalNav-link-careers'
    _perks = '//span[text()="Perks"]'
    _gallery = '//span[text()="Gallery"]'
    _employees_link = '//span[text()="Employees"]'
    _verify_employee_link = '//h1[text()="Help us grow our team!"]'
    _verify_employee_link_two = '//h2[text()="Employee Sign-in"]'
    _facebook_link = 'fa-facebook'
    _verify_facebook = 'facebook'
    _blog_link = 'fa-rss'
    _verify_blog = '#BLOG'
    _website_link = 'bzyButtonColor'
    _home_nav = "globalNav-link-experiences"
    _void_icon = 'brand'
    _view_openings = '//span[text()="View Openings"]'
    _verify_join_team = '//h1[text()="Hello. Welcome to The VOID!"]'
    _verify_perks = 'perks'
    _verify_gallery = 'gallery'
    _verify_openings = '//h1[text()="Our Openings"]'

# General methods
    def windowBefore(self):
        window_before = self.driver.window_handles[0]
        return self.driver.switch_to.window(window_before)

    def windowAfter(self):
        window_after = self.driver.window_handles[1]
        return self.driver.switch_to.window(window_after)

    def goBack(self):
        return self.driver.back()

    def closeWindow(self):
        return self.driver.close()

# Test methods
    def joinTeamNav(self):
        return self.elementClick(self._join_team_nav)

    def verifyJoinTeam(self):
        return self.isElementPresent(self._verify_join_team, locatorType='xpath')

    def perkLink(self):
        return self.elementClick(self._perks, locatorType='xpath')

    def galleryLink(self):
        return self.elementClick(self._gallery, locatorType='xpath')

    def employeesLink(self):
        return self.elementClick(self._employees_link, locatorType='xpath')

    def verifyEmployeesLink(self):
        url = 'https://the-void.breezy.hr/team/signin'
        if self.driver.current_url == url:
            return self.isElementPresent(self._verify_employee_link_two, locatorType='xpath')
        else:
            self.isElementPresent(self._verify_employee_link, locatorType='xpath')

    def facebookLink(self):
        return self.elementClick(self._facebook_link, locatorType='class')

    def verifyFacebook(self):
        return self.isElementPresent(self._verify_facebook)

    def blogLink(self):
        return self.elementClick(self._blog_link, locatorType='class')

    def verifyBlog(self):
        return self.driver.find_element_by_link_text(self._verify_blog)

    def websiteLink(self):
        return self.elementClick(self._website_link, locatorType='class')

    def verifyHomepage(self):
        return self.isElementPresent(self._home_nav)

    def voidIcon(self):
        return self.elementClick(self._void_icon, locatorType='class')

    def viewOpenings(self):
        return self.elementClick(self._view_openings, locatorType='xpath')

    def verifyOpenings(self):
        return self.isElementPresent(self._verify_openings, locatorType='xpath')

    def verifyPerks(self):
        return self.isElementPresent(self._verify_perks)

    def verifyGallery(self):
        return self.isElementPresent(self._verify_gallery)

    def checkJoinTeamLinks(self):
        self.joinTeamNav()
        time.sleep(2)
        self.closeWindow()
        self.windowBefore()
        self.verifyJoinTeam()
        self.perkLink()
        self.verifyPerks()
        self.galleryLink()
        self.verifyGallery()
        self.employeesLink()
        time.sleep(2)
        self.verifyEmployeesLink()
        self.goBack()
        self.facebookLink()
        time.sleep(2)
        self.verifyFacebook()
        self.goBack()
        self.blogLink()
        time.sleep(2)
        self.verifyBlog()
        self.goBack()
        self.websiteLink()
        time.sleep(2)
        self.verifyHomepage()
        self.joinTeamNav()
        time.sleep(2)
        self.windowAfter()
        self.voidIcon()
        time.sleep(2)
        self.verifyJoinTeam()
        self.viewOpenings()
        self.verifyOpenings()
        self.websiteLink()
        self.NotifySlack('Smoke test finished for https://the-void.breezy.hr/', self.SLACK_SPEAK)
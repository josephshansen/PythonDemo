from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the giftcard_tests.py are defined. 
"""

class GiftCardPage(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Selectors
    _choose_giftcard_link = 'button-viewGiftCards'
    _choose_giftcard_footer = 'footer-link-giftCards'
    _events_link = 'globalNav-link-events'
    _verify_giftcard_page = '//h1[contains(text()="Gift Cards")]'
    _faq_accordion_one = '//span[text()="Does The VOID offer gift cards?"]'
    _faq_accordion_one_expanded = 'online'
    _faq_accordion_two = '//span[text()="How do I redeem my VOID Gift Card?"]'
    _faq_accordion_two_expanded = 'THEVOID.com'
    _main_logo = "globalNav-link-home"
    # _faq_accordion_two_email = '//p[contains(text(), "mailto:support@thevoid.com")]'
    _view_faq = 'button-viewFaq'
    _verify_faq_page = '//span[text()="Frequently Asked Questions"]'
    _contact_page = 'button-viewContact'
    _verify_contact_page = '//span[text()="Contact Us"]'
    _buy_now = 'button-giftCard-BuyNow'
    _buy_now_modal = 'button-availableLocationPickerModal-bookNow'
    _verify_gift_card_location = '//span[text()="Orlando, FL"]'
    _gift_card_next = 'button-giftCard-stepOne-next'
    _verify_change_location = 'button-giftCard-changeLocation'
    _verify_gift_card_location_anaheim = '//span[text()="Anaheim, CA"]'
    _view_location = 'link-availableLocationPickerModal-viewLocation'
    _verify_anaheim_page = '//span[text()="The VOID Downtown Disney®"]'

# Locations List
    Anaheim = 'link-availableLocation-anaheim-downtown-disney'
    Glendale = 'link-availableLocation-los-angeles-glendale'
    SF = 'link-availableLocation-virtual-reality-san-francisco'
    SA = 'link-availableLocation-virtual-reality-arcadia'
    SM = 'link-availableLocation-santa-monica'
    Orlando = 'link-availableLocation-disney-springs-orlando'
    Atlanta = 'link-availableLocation-vr-atlanta'
    Minneapolis = 'link-availableLocation-virtual-reality-minneapolis'
    LV = 'link-availableLocation-virtual-reality-las-vegas'
    Plano = 'link-availableLocation-west-plano-cinemark'
    WashingtonDC = 'link-availableLocation-washington-dc'
    Edmonton = 'link-availableLocation-edmonton-canada'
    Toronto = 'link-availableLocation-vr-toronto'
    Mississauga = 'link-availableLocation-vr-mississauga'

    def chooseGiftCardLink(self):
        return self.elementClick(self._choose_giftcard_link)
    
    def chooseGiftCardFooter(self):
        return self.elementClick(self._choose_giftcard_footer)

    def goHome(self):
        return self.elementClick(self._main_logo)

    def verifyAnaheim(self):
        return self.isElementPresent(self.Anaheim)

    def verifyGlendale(self):
        return self.isElementPresent(self.Glendale)

    def verifySF(self):
        return self.isElementPresent(self.SF)

    def verifySA(self):
        return self.isElementPresent(self.SA)

    def verifySM(self):
        return self.isElementPresent(self.SM)

    def verifyAOrlando(self):
        return self.isElementPresent(self.Orlando)

    def verifyAtlanta(self):
        return self.isElementPresent(self.Atlanta)

    def verifyMinneapolis(self):
        return self.isElementPresent(self.Minneapolis)

    def verifyLV(self):
        return self.isElementPresent(self.LV)

    def verifyPlano(self):
        return self.isElementPresent(self.Plano)

    def verifyWashingtonDC(self):
        return self.isElementPresent(self.WashingtonDC)

    def verifyEdmonton(self):
        return self.isElementPresent(self.Edmonton)

    def verifyToronto(self):
        return self.isElementPresent(self.Toronto)

    def verifyMississauga(self):
        return self.isElementPresent(self.Mississauga)

    def selectOrlando(self):
        return self.elementClick(self.Orlando)


#     def verifyGiftCardList(self):
#         giftCardList = self.driver.find_elements_by_id(self.Anaheim, self.Glendale, \
# self.SF, self.SA, self.SM, self.Orlando, self.Atlanta, self.Minneapolis, \
# self.LV, self.Plano, self.Lindon, self.WashingtonDC, self.Edmonton, \
# self.Toronto, self.Mississauga)
#         assert giftCardList == True
#         if giftCardList == True:
#             return self.log.info("Correct List of Locations")
#         else:
#             self.log.error("One or more locations are missing")
            
    def verifyGiftcardPage(self):
        url = 'https://www.thevoid.com/virtual-reality-gift-cards/'
        if self.driver.current_url == url:
            return self.log.info("Gift Card Page Loaded")
        else:
            self.log.error("Gift Card Page Not Loading")

    def clickFAQAccordionOne(self):
        return self.elementClick(self._faq_accordion_one, locatorType='xpath')

    def verifyAccordionExpandedOne(self):
        return self.driver.find_element_by_link_text(self._faq_accordion_one_expanded).click()

    def clickFAQAccordionTwo(self):
        return self.elementClick(self._faq_accordion_two, locatorType='xpath')

    # def verifyEmailLink(self):
    #     return self.isElementPresent(self._faq_accordion_two_email, locatorType='xpath')

    def verifyAccordionExpandedTwo(self):
        return self.driver.find_element_by_link_text(self._faq_accordion_two_expanded).click()

    def verifyhomepage(self):
        return self.isElementPresent(self._main_logo)

    def viewFAQ(self):
        return self.elementClick(self._view_faq)

    def verifyFAQPage(self):
        url = 'https://www.thevoid.com/faq/'
        if self.driver.current_url == url:
            return self.isElementPresent(self._verify_faq_page, locatorType='xpath')
        else:
            self.log.error('FAQ Page Didn\'t Load')

    def viewContactPage(self):
        return self.elementClick(self._contact_page)

    def goBack(self):
        return self.driver.back()

    def verifyContactPage(self):
        url = 'https://www.thevoid.com/contact-us/'
        if self.driver.current_url == url:
            return self.isElementPresent(self._verify_contact_page, locatorType='xpath')
        else:
            self.log.error('Contact Page Didn\'t Load')

    def buyGiftCard(self):
        return self.elementClick(self._buy_now)

    def buyNowModal(self):
        return self.elementClick(self._buy_now_modal)

    def verifyLocationList(self):
        self.verifyAnaheim()
        self.verifyGlendale()
        self.verifySF()
        self.verifySA()
        self.verifySM()
        self.verifyAOrlando()
        self.verifyAtlanta()
        self.verifyMinneapolis()
        self.verifyLV()
        self.verifyPlano()
        self.verifyWashingtonDC()
        self.verifyEdmonton()
        self.verifyToronto()
        self.verifyMississauga()

    def verifyGiftCardLocationOrlando(self):
        return self.isElementPresent(self._verify_gift_card_location, locatorType='xpath')

    def changeLocation(self):
        return self.elementClick(self._verify_change_location)

    def changeLocationAnaheim(self):
        return self.elementClick(self.Anaheim)

    def changeLocationAnaheimOne(self):
        try:
            locationModal = self.driver.find_element(By.ID, self._modal).is_displayed
            locationModalSelected = self.driver.find_element(By.ID, self.Anaheim).isSelected()
            if locationModal and locationModalSelected:
                self.buyNowModal()
                self.log.info('Modal stayed open and Anaheim was previously selected')
            elif locationModal and not locationModalSelected:
                self.elementClick(self.Anaheim)
                time.sleep(3)
                self.buyNowModal()
                self.log.info('Modal stayed open but had to select Anaheim')
            else:
                self.changeLocation()
                time.sleep(3)
                self.elementClick(self.Anaheim)
                time.sleep(3)
                self.buyNowModal()
                self.log.info('Modal closed, so reopening')
        except:
            NoSuchElementException
            self.log.error('Modal couldnt be opened')

    def changeLocationAnaheimTwo(self):
        try:
            locationModal = self.driver.find_element(By.XPATH, self.verifyAnaheim).is_displayed
            if locationModal:
                self.verifyGiftCardLocationAnaheim()
                self.log.info('Modal stayed open')
            else:
                self.changeLocation()
                time.sleep(3)
                self.elementClick(self.Anaheim)
                time.sleep(3)
                self.buyNowModal()
                time.sleep(3)
                self.verifyGiftCardLocationAnaheim()
                self.log.info('Modal closed, so reselecting Anaheim')
        except:
            NoSuchElementException
            self.log.error('Modal couldnt be opened')

    def verifyGiftCardLocationAnaheim(self):
        return self.isElementPresent(self._verify_gift_card_location_anaheim, locatorType='xpath')

    def viewLocationAnaheim(self):
        return self.elementClick(self._view_location)

    def verifyLocationAnaheim(self):
        return self.isElementPresent(self._verify_anaheim_page, locatorType='xpath')

    def giftCardLinkCheck(self):
        self.chooseGiftCardLink()
        time.sleep(2)
        self.verifyGiftcardPage()
        # self.goBack()
        # time.sleep(2)
        self.viewFAQ()
        time.sleep(2)
        self.verifyFAQPage()
        self.goBack()
        time.sleep(2)
        self.viewContactPage()
        time.sleep(2)
        self.verifyContactPage()
        self.goBack()
        time.sleep(2)
        self.buyGiftCard()
        time.sleep(2)
        self.verifyLocationList()
        time.sleep(2)
        self.selectOrlando()
        time.sleep(2)
        self.buyNowModal()
        time.sleep(6)
        self.verifyGiftCardLocationOrlando()
        self.changeLocation()
        time.sleep(4)
        self.changeLocationAnaheim()
        time.sleep(2)
        self.buyNowModal()
        time.sleep(4)
        self.verifyGiftCardLocationAnaheim()
        time.sleep(4)
        self.changeLocation()
        time.sleep(4)
        self.viewLocationAnaheim()
        time.sleep(4)
        self.verifyLocationAnaheim()
        self.goBack()
        time.sleep(3)
        self.chooseGiftCardFooter()
        time.sleep(2)
        self.clickFAQAccordionOne()
        self.verifyAccordionExpandedOne()
        time.sleep(2)
        self.verifyGiftcardPage()
        self.clickFAQAccordionTwo()
        # self.verifyEmailLink()
        self.verifyAccordionExpandedTwo()
        self.NotifySlack('Smoke test finished for https://www.thevoid.com/virtual-reality-gift-cards/', self.SLACK_SPEAK)
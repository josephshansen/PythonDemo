from selenium import webdriver
from selenium.webdriver.common.by import By
from PROD.base.custom_webdriver import SeleniumDriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import time
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()

"""
This is where all elements for the void_story_tests.py are defined. 
"""

class VoidStoryPage(SeleniumDriver):

    SLACK_SPEAK = 1

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

# Locators
    _void_story_link = 'globalNav-link-about'
    _home_icon = 'globalNav-link-home'
    _play_video = 'button-aboutPage-playVideo'
    _experience_link = 'button-aboutPage-viewExperiences'
    _faq_link = 'button-aboutPage-viewFaq'
    _carousel_next = 'button-historyCarousel-viewNext'
    _carousel_prev = 'button-historyCarousel-viewPrev'
    _join_team_link = 'button-aboutPage-joinTeam'

# Verify Links
    _history_headset = '//span[text()="Rapture Headset"]'
    _history_haptics = '//span[text()="Rapture Haptics"]'
    _history_props = '//span[text()="High Accuracy Props"]'
    _history_blaster = '//span[text()="Rapture Blaster"]'
    _faq_page = '//span[text()="Frequently Asked Questions"]'
    _verify_dimension = '//span[text()="Explore another dimension"]'
    _verify_join_team = '//h1[text()="Hello. Welcome to The VOID!"]'
    _close_video = 'closeVideoLightbox'

# General element uses
    def goBack(self):
        return self.driver.back()

    def windowBefore(self):
        window_before = self.driver.window_handles[0]
        return self.driver.switch_to.window(window_before)

    def windowAfter(self):
        window_after = self.driver.window_handles[1]
        return self.driver.switch_to.window(window_after)

# Void Story Functions
    def goToVoidStoryPage(self):
        return self.elementClick(self._void_story_link)

    def goHome(self):
        return self.elementClick(self._home_icon)

    def openVideo(self):
        return self.elementClick(self._play_video)

    def experienceLink(self):
        return self.elementClick(self._experience_link)

    def faqLink(self):
        return self.elementClick(self._faq_link)

    def carouselNext(self):
        return self.elementClick(self._carousel_next)

    def carouselPrev(self):
        return self.elementClick(self._carousel_prev)

    def joinTeamLink(self):
        return self.elementClick(self._join_team_link)

    def closeVideo(self):
        return self.elementClick(self._close_video)

    def verifyExperience(self):
        return self.isElementPresent(self._verify_dimension, locatorType='xpath')

    def verifyFaq(self):
        return self.isElementPresent(self._faq_page, locatorType='xpath')

    def verifyHistoryHeadset(self):
        return self.isElementPresent(self._history_headset, locatorType='xpath')

    def verifyHistoryHaptics(self):
        return self.isElementPresent(self._history_haptics, locatorType='xpath')

    def verifyHistoryProps(self):
        return self.isElementPresent(self._history_props, locatorType='xpath')

    def verifyHistoryBlaster(self):
        return self.isElementPresent(self._history_blaster, locatorType='xpath')

    def verifyJoinTeam(self):
        return self.isElementPresent(self._verify_join_team, locatorType='xpath')

    def voidStoryTest(self):
        self.goToVoidStoryPage()
        time.sleep(2)
        self.openVideo()
        time.sleep(5)
        self.closeVideo()
        time.sleep(3)
        self.experienceLink()
        time.sleep(2)
        self.verifyExperience()
        self.goBack()
        time.sleep(2)
        self.faqLink()
        time.sleep(2)
        self.verifyFaq()
        self.goBack()
        time.sleep(2)
        self.verifyHistoryHeadset()
        time.sleep(2)
        self.carouselNext()
        time.sleep(2)
        self.verifyHistoryHaptics()
        self.carouselNext()
        time.sleep(2)
        self.verifyHistoryProps()
        self.carouselNext()
        time.sleep(2)
        self.verifyHistoryBlaster()
        self.carouselPrev()
        time.sleep(2)
        self.verifyHistoryProps()
        self.joinTeamLink()
        time.sleep(2)
        self.verifyJoinTeam()
        self.goBack()
        time.sleep(2)
        self.goHome()
        self.NotifySlack('Smoke test finished for https://www.thevoid.com/what-is-the-void', self.SLACK_SPEAK)
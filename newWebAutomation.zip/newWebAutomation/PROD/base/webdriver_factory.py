import traceback
from selenium import webdriver

"""
This method -when working properly- will keep us from setting the driver path, and calling the URL in each test file
"""

class webDriverFactory():

    def __init__(self, browser):
        self.browser = browser
        
    def getWebdriverInstance(self):
        baseURL = "https://www.thevoid.com/"
        if self.browser == "edge":
            driver = webdriver.Edge()
        elif self.browser == "firefox":
            driver = webdriver.Firefox()
        elif self.browser == "chrome":
            driver = webdriver.Chrome()
        else:
            driver = webdriver.Chrome()
        driver.implicitly_wait(3)
        driver.maximize_window()
        driver.get(baseURL)
        return driver
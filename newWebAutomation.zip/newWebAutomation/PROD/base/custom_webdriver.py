from selenium.webdriver.common.by import By
from traceback import print_stack
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException
import PROD.utilities.custome_logger as cl
import coloredlogs, logging
coloredlogs.install()
import time
import requests
import json
import os
from pprint import pprint

"""
These methods mostly are utilizing selenium actions such as (find element, click element, enter text, etc), but they also include logging.
"""

class SeleniumDriver():

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        self.driver = driver

    def screenShot(self, resultMessage):
        """
        Takes screenshot of the current open web page
        """
        fileName = resultMessage + "." + str(round(time.time() * 1000)) + ".png"
        screenshotDirectory = "../screenshots/"
        relativeFileName = screenshotDirectory + fileName
        currentDirectory = os.path.dirname(__file__)
        destinationFile = os.path.join(currentDirectory, relativeFileName)
        destinationDirectory = os.path.join(currentDirectory, screenshotDirectory)

        try:
            if not os.path.exists(destinationDirectory):
                os.makedirs(destinationDirectory)
            self.driver.save_screenshot(destinationFile)
            self.log.info("Screenshot save to directory: " + destinationFile)
        except:
            self.log.error("### Exception Occurred when taking screenshot")
            print_stack()

    webhook = "https://hooks.slack.com/services/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"

    SLACK_SPEAK = 1

    def NotifySlack(self, msg, speak):
        if speak:
            webhook = "https://hooks.slack.com/services/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"
            payload = {"text": msg, "channel": "automatonroom"}
            r = requests.post(webhook, json=payload)
            self.log.error(r.text)
            self.log.error(r.status_code)
        return msg

    def getByType(self, locatorType, *msg):
        locatorType = locatorType.lower()
        if locatorType == "id":
            return By.ID
        elif locatorType == "name":
            return By.NAME
        elif locatorType == "xpath":
            return By.XPATH
        elif locatorType == "css":
            return By.CSS_SELECTOR
        elif locatorType == "class":
            return By.CLASS_NAME
        elif locatorType == "link":
            return By.LINK_TEXT
        else:
            self.log.error("Locator type " + locatorType +
                          " not correct/supported")
            self.NotifySlack('Locator type ' + locatorType + 'not supported', self.SLACK_SPEAK)
        return False

    def getElement(self, locator, locatorType="id", *msg):
        element = None
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_element(byType, locator)
            self.log.info("Element found with locator: " + locator +
                          " and  locatorType: " + locatorType)
        except:
            self.log.error("Element not found with locator: " + locator +
                          " and  locatorType: " + locatorType)
            self.NotifySlack("Element not found with locator: " + locator +
                          " and  locatorType: " + locatorType, self.SLACK_SPEAK)
        return element

    def elementClick(self, locator, locatorType="id", *msg):
        try:
            element = self.getElement(locator, locatorType)
            element.click()
            self.log.info("Clicked on element with locator: " + locator +
                          " locatorType: " + locatorType)
        except:
            self.log.error("Cannot click on the element with locator: " + locator +
                          " locatorType: " + locatorType)
            self.NotifySlack("Cannot click on the element with locator: " + locator +
                          " locatorType: " + locatorType, self.SLACK_SPEAK)
            print_stack()

    def elementDisplayed(self, locator, locatorType="id", timeout=20, poll_frequency=0.5, *msg):
        try:
            element = self.getElement(locator, locationType).is_displayed
            self.log.info("Element is displayed: " + locator + " locatoryType: " + locatorType)
            if element is not None:
                self.log.info("Element Found with locator: " + locator + " locatoryType: " + locationType)
                return True
            else:
                wait = WebDriverWait(self.driver, 10, poll_frequency=1,
                                ignored_exceptions=[NoSuchElementException,
                                                    ElementNotVisibleException,
                                                    ElementNotSelectableException])
            element = wait.until(EC.visibility_of_element_located((locator, locatorType)))
            self.log.info("Element appeared on the web page with locator: " + locator + " locatorType: " + locationType)
            return True
        except:
            self.log.error("Element never appeared with locator: " + locator +
                          " locatorType: " + locatorType)
            self.NotifySlack("Element never appeared with locator: " + locator +
                          " locatorType: " + locatorType, self.SLACK_SPEAK)
            print_stack()

    def elementDisplayedClick(self, locator, locatorType="id", timeout=10, poll_frequency=0.5, *msg):
        element = self.getElement(locator, locatorType).click()
        try:
            if element is not None:
                self.log.info("Element Found with locator: " + locator + " locatoryType: " + locationType)
                return element
            else:
                wait = WebDriverWait(self.driver, 10, poll_frequency=0.5,
                                ignored_exceptions=[NoSuchElementException,
                                                    ElementNotVisibleException,
                                                    ElementNotSelectableException])
            element = wait.until(EC.visibility_of_element_located((locator, locatorType)))
            self.log.info("Element appeared on the web page with locator: " + locator + " locatorType: " + locationType)
            return element
        except:
            self.log.error("Element never appeared with locator: " + locator +
                          " locatorType: " + locatorType)
            self.NotifySlack("Element never appeared with locator: " + locator +
                          " locatorType: " + locatorType, self.SLACK_SPEAK)
            print_stack()

    def sendKeys(self, data, locator, locatorType="id", *msg):
        try:
            element = self.getElement(locator, locatorType)
            element.send_keys(data)
            self.log.info("Sent data on element with locator: " + locator +
                          " locatorType: " + locatorType)
        except:
            self.log.error("Cannot send data on the element with locator: " + locator +
                  " locatorType: " + locatorType)
            self.NotifySlack("Cannot send data on the element with locator: " + locator +
                  " locatorType: " + locatorType, self.SLACK_SPEAK)
            print_stack()

    def isElementPresent(self, locator, locatorType="id"):
        try:
            element = self.getElement(locator, locatorType)
            if element is not None:
                self.log.info(locator + " Element Found")
                return True
            else:
                self.log.error("Element not found with locator: " + locator +
                    " locatorType: " + locatorType)
                self.NotifySlack("Element not found with locator: " + locator +
                    " locatorType: " + locatorType, self.SLACK_SPEAK)
                return False
        except:
            self.log.error("Element not found")
            self.NotifySlack("Element not found with locator: " + locator +
                    " locatorType: " + locatorType, self.SLACK_SPEAK)
            return False

    def elementPresenceCheck(self, locator, locatorType="id", *msg):
        try:
            element = self.getElement(locator, locatorType)
            if element is not None:
                self.log.info(locator + " Element Found")
                return True
            else:
                self.log.error(locator + " Element not found")
                self.NotifySlack("Element not found with locator: " + locator +
                    " locatorType: " + locatorType, self.SLACK_SPEAK)
                return False
        except:
            self.log.error("Element not found")
            self.NotifySlack("Element not found with locator: " + locator +
                    " locatorType: " + locatorType, self.SLACK_SPEAK)
            self.screenShot("Element found with locator: " + locator +
                          " and  locatorType: " + locatorType)
            return False

    def elementVisible(self, locator, locatorType="id", *msg):
        try:
            element = self.getElement(locator, locatorType).is_displayed()
            if element is not None:
                self.log.info(locator + " Element Found")
                return True
            else:
                self.log.error("Element not found")
                self.NotifySlack("Element not found with locator: " + locator +
                    " locatorType: " + locatorType, self.SLACK_SPEAK)
                return False
        except:
            self.log.error("Element not found")
            self.NotifySlack("Element not found with locator: " + locator +
                    " locatorType: " + locatorType, self.SLACK_SPEAK)
            return False

    def checkBoxClick(self, locator, locatorType='id'):
            element =  self.getElement(locator, locatorType).is_selected()
            if element:
                self.log.info("Element Already Checked")
            else:
                self.getElement(locator, locatorType).click()
                self.log.info("Element Checked Now")

    def accordionExpanded(self, locator, locationType='id', *msg):
        element = self.elementVisible(locator, locationType)
        notElement = self.elementVisible(locator, locationType)
        if element:
            self.log.info("Accordian Expanded")
        elif notElement:
            self.elementClick(locator, locationType)
            if element:
                self.log.info("Accordian Expanded Now")
            else:
                self.log.info("Accordian not Expanding")
        else:
            self.log.error("Accordian not Working")
            self.NotifySlack("Accordian not Working", self.SLACK_SPEAK)


    def waitForElement(self, locator, locatorType="id", 
                            timeout=5):
        element = None
        try:
            byType = self.getByType(locatorType)
            self.log.info("Waiting for maximum :: " + str(timeout) +
                  " :: seconds for element to be clickable")
            element = WebDriverWait(self.driver, 5,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException]).until(EC.presence_of_element_located((byType,
                                                             "stopFilter_stops-0")))
            self.log.info(locator + " Element appeared on the web page")
            return element
        except:
            self.log.error(locator + " Element not appeared on the web page")
            print_stack()
        return element

    # def waitForElementVisible(self, locator, locatorType="id", 
    #                     timeout=20, poll_frequency=0.5, *msg):
    #     element = None
    #     try:
    #         byType = self.getByType(locatorType)
    #         self.log.info("Waiting for maximum :: " + str(timeout) +
    #               " :: seconds for element to be clickable")
    #         wait = WebDriverWait(self.driver, 5,
    #                              ignored_exceptions=[NoSuchElementException,
    #                                                  ElementNotVisibleException,
    #                                                  ElementNotSelectableException])
    #         element = wait.until(EC.presence_of_element_located((byType,
    #                                                          "stopFilter_stops-0")))
    #         self.log.info("Element appeared on the web page")
    #     except:
    #         self.log.error("Element not appeared on the web page")
    #         print_stack()
    #     return element

    # def waitForElementVisible(self, locator, locatorType="id", 
    #                     timeout=20, poll_frequency=0.5, *msg):
    #     element = None
    #     try:
    #         byType = self.getByType(locatorType)
    #         self.log.info("Waiting for maximum :: " + str(timeout) +
    #               " :: seconds for element to be clickable")
    #         wait = WebDriverWait(self.driver, timeout,
    #                              ignored_exceptions=[NoSuchElementException,
    #                                                  ElementNotVisibleException,
    #                                                  ElementNotSelectableException])
    #         element = wait.until(EC.presence_of_element_located((byType,
    #                                                          "stopFilter_stops-0")))
    #         self.log.info("Element " + locator + " appeared on the web page")
    #         return element
    #     except:
    #         self.log.error("Element " + locator + " did not appear on the web page")
    #         print_stack()
    #     return element

    def waitForElementVisible(self, locator, locatorType="id", 
                        timeout=20, poll_frequency=0.5, *msg):
        element = None
        try:
            byType = self.getByType(locatorType)
            self.log.info("Waiting for maximum :: " + str(timeout) +
                  " :: seconds for element to be clickable")
            element = WebDriverWait(self.driver, timeout,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException]).until(EC.presence_of_element_located((byType,
                                                             "stopFilter_stops-0")))
            self.log.info("Element " + locator + " appeared on the web page")
            return element
        except:
            self.log.error("Element " + locator + " did not appear on the web page")
            print_stack()
        return element

    # def waitForElementVisible(self, locator, locatorType="id", 
    #                     timeout=20, poll_frequency=0.5, *msg):
    #     element = None
    #     try:
    #         locatorType = self.getByType(locatorType)
    #         wait = WebDriverWait(self.driver, 10, poll_frequency=1,
    #                             ignored_exceptions=[NoSuchElementException,
    #                                                 ElementNotVisibleException,
    #                                                 ElementNotSelectableException])
    #         element = wait.until(EC.visibility_of_element_located((locatorType)))
    #         self.log.info("Element appeared on the web page")
    #     except:
    #         self.log.error("Element not appeared on the web page")
    #         self.NotifySlack("Element not found with locator: " + locator +
    #                 " locatorType: " + locatorType, self.SLACK_SPEAK)
    #         print_stack()
    #     return element

    # def waitForElementClick(self, locator, locatorType="id", 
    #                     timeout=20, poll_frequency=0.5, *msg):
    #     element = None
    #     try:
    #         locatorType = self.getElement(locator, locatorType).click()
    #         wait = WebDriverWait(self.driver, 10, poll_frequency=1,
    #                             ignored_exceptions=[NoSuchElementException,
    #                                                 ElementNotVisibleException,
    #                                                 ElementNotSelectableException])
    #         element = wait.until(EC.element_to_be_clickable((locatorType)))
    #         self.log.info("Element appeared on the web page")
    #     except:
    #         self.log.error("Element not appeared on the web page")
    #         self.NotifySlack("Element not found with locator: " + locator +
    #                 " locatorType: " + locatorType, self.SLACK_SPEAK)
    #         print_stack()
    #     return element